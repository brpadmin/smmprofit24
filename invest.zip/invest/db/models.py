from sqlalchemy import (BigInteger, Boolean, Column, Float, ForeignKey,
                        Integer, String, Text)
from sqlalchemy.orm import relationship

from db.base import Base


class Invester(Base):
    __tablename__ = "invester"

    id = Column(BigInteger, unique=True, primary_key=True)
    username = Column(String(255))
    status = Column(String(20), default="user")
    join_date = Column(BigInteger)

    first_invest_date = Column(BigInteger, default=0)

    referrer = Column(BigInteger)
    ref_count = Column(Integer, default=0)
    active_refs = Column(Integer, default=0)
    ref_link = Column(String(255))

    total_ref_cash = Column(Float, default=0)
    balance = Column(Float, default=0)

    withdraw = Column(String(20), default="allowed")
    is_blocked = Column(String(20), default="not_blocked")


class InvestSettings(Base):
    __tablename__ = "investsettings"

    id = Column(String(10), primary_key=True)

    total_users = Column(Integer, default=0)
    total_investers = Column(Integer, default=0)

    total_invests = Column(Float, default=0)
    profit = Column(Float, default=0)

    ref_first = Column(Float, default=1)
    ref_second = Column(Float, default=0.5)
    ref_third = Column(Float, default=0.25)

    invest_amount = Column(Float, default=100)
    withdraw_amount = Column(Float, default=100)

    hello_msg = Column(Text)
    proj_msg = Column(Text)
    info_msg = Column(Text)

    qiwi_wallet = Column(String(20))
    qiwi_api = Column(String(255))
    qiwi_ptp = Column(String(255))

    qiwi_pay = Column(String(5), default="on")
    maintentance = Column(String(5), default="off")


class WithrawOrder(Base):
    __tablename__ = "withdraworder"

    id = Column(Integer, unique=True, autoincrement=True, primary_key=True)
    status = Column(String(20), default="cheking")

    user_id = Column(BigInteger)
    username = Column(String(255))

    amount = Column(Float)
    wallet = Column(String(255))


class Order(Base):
    __tablename__ = "order"

    id = Column(Integer, unique=True, autoincrement=True, primary_key=True)

    user_id = Column(BigInteger)

    amount = Column(Float)
    code = Column(Integer)
    bill_id = Column(String(255))
    status = Column(String(15), default="not_paid")


class BalanceChange(Base):
    __tablename__ = "balancechange"

    id = Column(BigInteger, unique=True, autoincrement=True, primary_key=True)
    change_from = Column(String(20))
    change_type = Column(String(5))

    amount = Column(Float)

    date_str = Column(String(20))
    date_int = Column(BigInteger)

    ref_name = Column(String(255))
    ref_lvl = Column(Integer)

    user_id = Column(BigInteger)


class MessageHistory(Base):
    __tablename__ = "messagehistory"

    id = Column(BigInteger, unique=True, autoincrement=True, primary_key=True)
    date = Column(String(15))
    msg_to = Column(String(20))
    text = Column(Text)
    image = Column(String(20))
