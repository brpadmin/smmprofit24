import asyncio
import datetime as dt
import logging

import pytz
from aiogram.utils.deep_linking import get_start_link
from sqlalchemy import select, update

from db.models import BalanceChange as BC
from db.models import Invester
from db.models import InvestSettings as ISet
from db.models import MessageHistory, Order
from db.models import WithrawOrder as WO


async def check_or_add_user(db, user_id, referrer_id, username):
    async with db() as ssn:
        setts = await ssn.get(ISet, "main")
        if not setts:
            await ssn.merge(ISet(
                id="main",
                hello_msg="Какой-то текст",
                proj_msg="Какой-то текст",
                info_msg="Какой-то текст"))
            await ssn.commit()

        user: Invester = await ssn.get(Invester, user_id)

        if not user:
            date_now = int(dt.datetime.now(
                tz=pytz.timezone("Europe/Moscow")).timestamp())
            link = await get_start_link(user_id)

            await ssn.merge(Invester(
                id=user_id,
                username=username,
                join_date=date_now,
                referrer=referrer_id,
                ref_link=link
            ))

            if referrer_id != 0:
                ref_usr: Invester = await ssn.get(Invester, referrer_id)

                if ref_usr:
                    ref_usr.ref_count += 1

            await ssn.execute(update(ISet).filter(ISet.id == "main").values(total_users=ISet.total_users + 1))
            await ssn.commit()
            logging.info(
                f"Новый пользователь {user_id} - реферер {referrer_id}")
            await ssn.close()

            return "user"

        else:
            status = user.status

        await ssn.close()

    return status


async def get_profile(db, user_id):
    async with db() as ssn:
        user_q = await ssn.execute(select(Invester).filter(Invester.id == user_id))
        user_res = user_q.fetchone()

        if not user_res:
            await ssn.close()
            return False

        user = user_res[0]
        await ssn.close()

    return user


async def create_withdraw_order(db, user_id, amount, username, wallet):
    format_amount = float("{:.2f}".format(amount))
    if amount < format_amount:
        format_amount = (float("{:.2f}".format(amount)) - 0.01)

    async with db() as ssn:
        wd = await ssn.merge(WO(
            user_id=user_id,
            username=username,
            amount=format_amount,
            wallet=wallet
        ))
        await ssn.execute(update(Invester).filter(Invester.id == user_id).values(
            balance=Invester.balance - format_amount,
            withdraw="not_allowed"
        ))
        await ssn.commit()
        w_id = wd.id
        await ssn.close()

    return w_id


async def get_stats(db):
    async with db() as ssn:
        setts_q = await ssn.execute(select(ISet).filter(ISet.id == "main"))
        setts = setts_q.fetchone()[0]

        tz = pytz.timezone("Europe/Moscow")
        one_day_early = int(
            (dt.datetime.now(tz=tz) - dt.timedelta(hours=24)).timestamp())
        new_users_q = await ssn.execute(select(Invester).filter(Invester.join_date >= one_day_early))
        new_users = new_users_q.scalars().all()

        new_investors_q = await ssn.execute(select(Invester).filter(Invester.first_invest_date >= one_day_early))
        new_investors = new_investors_q.scalars().all()

        await ssn.close()

    return {
        "setts": setts,
        "new_users": len(new_users),
        "new_investors": len(new_investors)
    }


async def change_message(db, msg, text):
    async with db() as ssn:
        if msg == "change_hello":
            await ssn.execute(update(ISet).filter(ISet.id == "main").values(hello_msg=text))

        elif msg == "change_proj":
            await ssn.execute(update(ISet).filter(ISet.id == "main").values(proj_msg=text))

        else:
            await ssn.execute(update(ISet).filter(ISet.id == "main").values(info_msg=text))

        await ssn.commit()
        await ssn.close()

    return True


async def change_percents(db, ref_first, ref_second, ref_third):
    async with db() as ssn:
        await ssn.execute(update(ISet).filter(ISet.id == "main").values(
            ref_first=ref_first, ref_second=ref_second, ref_third=ref_third))
        await ssn.commit()
        await ssn.close()

    return True


async def change_invest_amount(db, new_amount):
    async with db() as ssn:
        await ssn.execute(update(ISet).filter(ISet.id == "main").values(
            invest_amount=new_amount))
        await ssn.commit()
        await ssn.close()

    return True


async def change_withdraw_amount(db, new_amount):
    async with db() as ssn:
        await ssn.execute(update(ISet).filter(ISet.id == "main").values(
            withdraw_amount=new_amount))
        await ssn.commit()
        await ssn.close()

    return True


async def change_wallet(db, num):
    async with db() as ssn:
        await ssn.execute(update(ISet).filter(ISet.id == "main").values(
            qiwi_wallet=num))
        await ssn.commit()
        await ssn.close()

    return True


async def change_qiwi(db, token, action):
    async with db() as ssn:
        if action == "qiwi_api":
            await ssn.execute(update(ISet).filter(ISet.id == "main").values(
                qiwi_api=token))
        else:
            await ssn.execute(update(ISet).filter(ISet.id == "main").values(
                qiwi_ptp=token))
        await ssn.commit()
        await ssn.close()

    return True


async def get_wd_orders(db):
    async with db() as ssn:
        orders_q = await ssn.execute(select(WO).filter(WO.status == "cheking"))
        orders = orders_q.scalars().all()
        await ssn.close()

    return orders


async def get_wd_info(db, w_id):
    async with db() as ssn:
        wd: WO = await ssn.get(WO, w_id)
        wallet = wd.wallet
        amount = wd.amount
        status = wd.status
        await ssn.close()

    return [wallet, amount, status]


async def withdraw_result(db, w_id, result):
    async with db() as ssn:
        wd: WO = await ssn.get(WO, w_id)

        if wd.status != "cheking":
            return False

        user_id = wd.user_id
        amount = wd.amount

        if result == "accept":
            tz = pytz.timezone("Europe/Moscow")
            date_now = int(dt.datetime.now(tz=tz).timestamp())
            now_date = dt.datetime.now(tz=tz).strftime("%d.%m.%Y")

            wd.status = "accepted"
            await ssn.execute(update(Invester).filter(
                Invester.id == wd.user_id).values(withdraw="allowed"))

            await ssn.merge(BC(
                change_from="user",
                change_type="out",
                amount=amount,
                date_str=now_date,
                date_int=date_now,
                user_id=user_id
            ))

        else:
            wd.status = "declined"
            await ssn.execute(update(Invester).filter(
                Invester.id == wd.user_id).values(
                    withdraw="allowed", balance=Invester.balance + amount))

        await ssn.commit()
        await ssn.close()

    return [user_id, amount]


async def get_wd_user_id(db, w_id):
    async with db() as ssn:
        wd: WO = await ssn.get(WO, w_id)
        user_id = wd.user_id
        await ssn.close()

    return user_id


async def get_all_users(db):
    async with db() as ssn:
        users_q = await ssn.execute(select(Invester))
        users = users_q.scalars().all()
        await ssn.close()

    return users


async def get_all_investors(db, action):
    async with db() as ssn:
        if action in ["inv_in_msg", "inv_in_xlsx"]:
            investors_q = await ssn.execute(select(Invester).filter(
                Invester.status == "investor").order_by(Invester.ref_count.desc()))
            investors = investors_q.scalars().all()

        else:
            limit = action.split("_")[1]

            investors_q = await ssn.execute(select(Invester).filter(
                Invester.status == "investor").order_by(Invester.ref_count.desc()).limit(int(limit)))
            investors = investors_q.scalars().all()

        await ssn.close()

    return investors


async def get_all_blocked(db):
    async with db() as ssn:
        users_q = await ssn.execute(select(Invester).filter(Invester.is_blocked == "blocked"))
        users = users_q.scalars().all()
        await ssn.close()

    return users


async def block_list_db(db, action, user_id):
    async with db() as ssn:
        if action == "give_access":
            date_now = int(dt.datetime.now(
                tz=pytz.timezone("Europe/Moscow")).timestamp())

            user: Invester = await ssn.get(Invester, user_id)
            user.status = "investor"
            user.first_invest_date = date_now

            if user.referrer != 0:
                await ssn.execute(update(Invester).filter(
                    Invester.id == user.referrer).values(
                        active_refs=Invester.active_refs + 1))

            await ssn.execute(update(ISet).filter(ISet.id == "main").values(
                total_investers=ISet.total_investers + 1))

        elif action == "add_to_bl":
            await ssn.execute(update(Invester).filter(
                Invester.id == user_id).values(is_blocked="blocked"))
        else:
            await ssn.execute(update(Invester).filter(
                Invester.id == user_id).values(is_blocked="not_blocked"))
        await ssn.commit()
        await ssn.close()

    return True


async def get_users_for_msgs(db, action):
    async with db() as ssn:
        if action == "msgs_to_novice":
            tz = pytz.timezone("Europe/Moscow")
            one_day_early = int(
                (dt.datetime.now(tz=tz) - dt.timedelta(hours=24)).timestamp())

            users_q = await ssn.execute(select(Invester).filter(Invester.join_date >= one_day_early))
            users = users_q.scalars().all()

        elif action == "msgs_to_invs":
            users_q = await ssn.execute(select(Invester).filter(Invester.status == "investor"))
            users = users_q.scalars().all()

        else:
            users_q = await ssn.execute(select(Invester))
            users = users_q.scalars().all()

        await ssn.close()

    return users


async def get_messages(db):
    async with db() as ssn:
        setts: ISet = await ssn.get(ISet, "main")

        hello = setts.hello_msg
        proj = setts.proj_msg
        info = setts.info_msg

        await ssn.close()

    return [hello, proj, info]


async def get_bot_wallet(db):
    async with db() as ssn:
        setts: ISet = await ssn.get(ISet, "main")
        wallet = setts.qiwi_wallet
        amount = setts.invest_amount
        await ssn.close()

    return [wallet, amount]


async def add_new_invest(db, user_id, amount, code, bill_id):
    async with db() as ssn:
        invest = await ssn.merge(Order(
            user_id=user_id,
            amount=amount,
            code=code,
            bill_id=bill_id
        ))
        await ssn.commit()
        invest_id = invest.id
        await ssn.close()

    return invest_id


async def get_invest_id_info(db, order_id):
    async with db() as ssn:
        order: Order = await ssn.get(Order, order_id)
        setts: ISet = await ssn.get(ISet, "main")
        amount = order.amount
        code = order.code
        qiwi_token = setts.qiwi_api
        qiwi_phone = setts.qiwi_wallet
        await ssn.close()

    return [amount, code, qiwi_token, qiwi_phone]


async def confirmed_invest(db, order_id):
    async with db() as ssn:
        order: Order = await ssn.get(Order, order_id)
        if order.status != "not_paid":
            return False

        setts: ISet = await ssn.get(ISet, "main")
        new_invester: Invester = await ssn.get(Invester, order.user_id)

        tz = pytz.timezone("Europe/Moscow")
        date_now = int(dt.datetime.now(tz=tz).timestamp())
        now_date = dt.datetime.now(tz=tz).strftime("%d.%m.%Y")

        new_invester.status = "investor"
        new_invester.first_invest_date = date_now

        amount = order.amount
        ref_profits = 0
        if new_invester.referrer != 0:
            first_ref: Invester = await ssn.get(Invester, new_invester.referrer)
            if first_ref:

                first_profit = float("{:.2f}".format(
                    amount * (setts.ref_first / 100)))

                if (amount * (setts.ref_first / 100)) < first_profit:
                    first_profit -= 0.01

                ref_profits += first_profit

                first_ref.balance += first_profit
                first_ref.total_ref_cash += first_profit
                first_ref.active_refs += 1

                await ssn.merge(BC(
                    change_from="ref",
                    change_type="in",
                    amount=first_profit,
                    date_str=now_date,
                    date_int=date_now,
                    ref_name=new_invester.username,
                    ref_lvl=1,
                    user_id=new_invester.referrer
                ))
            # 111
            if first_ref.referrer != 0:
                second_ref: Invester = await ssn.get(Invester, first_ref.referrer)
                if second_ref:
                    second_profit = float("{:.2f}".format(
                        amount * (setts.ref_second / 100)))

                    if (amount * (setts.ref_second / 100)) < second_profit:
                        second_profit -= 0.01

                    ref_profits += second_profit

                    second_ref.balance += second_profit
                    second_ref.total_ref_cash += second_profit

                    await ssn.merge(BC(
                        change_from="ref",
                        change_type="in",
                        amount=second_profit,
                        date_str=now_date,
                        date_int=date_now,
                        ref_name=new_invester.username,
                        ref_lvl=2,
                        user_id=first_ref.referrer
                    ))
                # 222
                if second_ref.referrer != 0:
                    third_ref: Invester = await ssn.get(Invester, second_ref.referrer)
                    if third_ref:
                        third_profit = float("{:.2f}".format(
                            amount * (setts.ref_third / 100)))

                        if (amount * (setts.ref_third / 100)) < third_profit:
                            third_profit -= 0.01

                        ref_profits += third_profit

                        third_ref.balance += third_profit
                        third_ref.total_ref_cash += third_profit

                        await ssn.merge(BC(
                            change_from="ref",
                            change_type="in",
                            amount=third_profit,
                            date_str=now_date,
                            date_int=date_now,
                            ref_name=new_invester.username,
                            ref_lvl=3,
                            user_id=second_ref.referrer
                        ))

                    # 333

        await ssn.commit()
        profit = amount - ref_profits
        setts.total_investers += 1
        setts.total_invests += amount
        setts.profit += profit

        order.status = "paid"
        await ssn.commit()

        await ssn.close()

    return True


async def get_settings(db):
    async with db() as ssn:
        setts_q = await ssn.execute(select(ISet).filter(ISet.id == "main"))
        setts = setts_q.fetchone()[0]
        await ssn.close()

    return setts


async def change_maintentnce(db, action):
    async with db() as ssn:
        if action == "mtns_on":
            await ssn.execute(update(ISet).filter(ISet.id == "main").values(maintentance="on"))
        else:
            await ssn.execute(update(ISet).filter(ISet.id == "main").values(maintentance="off"))
        await ssn.commit()
        await ssn.close()

    return True


async def dividends_to_one(db, user_id, amount, action):
    tz = pytz.timezone("Europe/Moscow")
    date_now = int(dt.datetime.now(tz=tz).timestamp())
    now_date = dt.datetime.now(tz=tz).strftime("%d.%m.%Y")

    async with db() as ssn:
        if action == "add":
            await ssn.execute(update(Invester).filter(Invester.id == user_id).values(
                total_ref_cash=Invester.total_ref_cash+amount, balance=Invester.balance+amount))

            await ssn.merge(BC(
                change_from="admin",
                change_type="in",
                amount=amount,
                date_str=now_date,
                date_int=date_now,
                user_id=user_id
            ))

        else:
            await ssn.execute(update(Invester).filter(Invester.id == user_id).values(
                total_ref_cash=Invester.total_ref_cash-amount, balance=Invester.balance-amount))

            await ssn.merge(BC(
                change_from="admin",
                change_type="out",
                amount=amount,
                date_str=now_date,
                date_int=date_now,
                user_id=user_id
            ))

        await ssn.commit()
        await ssn.close()

    return True


async def dividends_to_many(db, count, amount, action):
    tz = pytz.timezone("Europe/Moscow")
    date_now = int(dt.datetime.now(tz=tz).timestamp())
    now_date = dt.datetime.now(tz=tz).strftime("%d.%m.%Y")

    async with db() as ssn:
        if count == 0:
            if action == "add":
                await ssn.execute(update(Invester).filter(
                    Invester.status == "investor").values(
                        total_ref_cash=Invester.total_ref_cash+amount, balance=Invester.balance+amount))

                investors_q = await ssn.execute(select(Invester).filter(
                    Invester.status == "investor"))
                investors = investors_q.scalars().all()

                invv: Invester
                for invv in investors:
                    await ssn.merge(BC(
                        change_from="admin",
                        change_type="in",
                        amount=amount,
                        date_str=now_date,
                        date_int=date_now,
                        user_id=invv.id
                    ))
                    await asyncio.sleep(.02)
            else:
                await ssn.execute(update(Invester).filter(
                    Invester.status == "investor").values(
                        total_ref_cash=Invester.total_ref_cash-amount, balance=Invester.balance-amount))

                investors_q = await ssn.execute(select(Invester).filter(
                    Invester.status == "investor"))
                investors = investors_q.scalars().all()

                invv: Invester
                for invv in investors:
                    await ssn.merge(BC(
                        change_from="admin",
                        change_type="out",
                        amount=amount,
                        date_str=now_date,
                        date_int=date_now,
                        user_id=invv.id
                    ))
                    await asyncio.sleep(.02)
        else:
            investors_q = await ssn.execute(select(Invester).filter(
                Invester.status == "investor").order_by(
                    Invester.ref_count.desc()).limit(count))
            investors = investors_q.scalars().all()

            if action == "add":
                inv: Invester
                for inv in investors:
                    await ssn.execute(update(Invester).filter(Invester.id == inv.id).values(
                        total_ref_cash=Invester.total_ref_cash+amount, balance=Invester.balance+amount))

                    await ssn.merge(BC(
                        change_from="admin",
                        change_type="in",
                        amount=amount,
                        date_str=now_date,
                        date_int=date_now,
                        user_id=inv.id
                    ))
                    await asyncio.sleep(.02)
            else:
                inv: Invester
                for inv in investors:
                    await ssn.execute(update(Invester).filter(Invester.id == inv.id).values(
                        total_ref_cash=Invester.total_ref_cash-amount, balance=Invester.balance-amount))

                    await ssn.merge(BC(
                        change_from="admin",
                        change_type="out",
                        amount=amount,
                        date_str=now_date,
                        date_int=date_now,
                        user_id=inv.id
                    ))
                    await asyncio.sleep(.02)

        await ssn.commit()
        await ssn.close()

    return investors


async def get_referrals(db, user_id):
    async with db() as ssn:
        users_q = await ssn.execute(select(Invester).filter(
            Invester.referrer == user_id).filter(
                Invester.status == "user"))
        users = users_q.scalars().all()

        invs_q = await ssn.execute(select(Invester).filter(
            Invester.referrer == user_id).filter(
                Invester.status == "investor"))
        invs = invs_q.scalars().all()
        await ssn.close()

    return [users, invs]


async def get_user_id_from_wd(db, w_id):
    async with db() as ssn:
        wd: WO = await ssn.get(WO, w_id)
        user_id = wd.user_id
        await ssn.close()

    return user_id


async def change_qiwipay(db, action):
    async with db() as ssn:
        if action == "qiwi_on":
            await ssn.execute(update(ISet).filter(ISet.id == "main").values(qiwi_pay="on"))
        else:
            await ssn.execute(update(ISet).filter(ISet.id == "main").values(qiwi_pay="off"))
        await ssn.commit()
        await ssn.close()

    return True


async def get_histrory(db, user_id):
    async with db() as ssn:
        history_q = await ssn.execute(select(BC).filter(
            BC.user_id == user_id).order_by(BC.id.desc()))
        history = history_q.scalars().all()
        await ssn.close()

    return history


async def user_get_history(db, user_id):
    async with db() as ssn:
        history_q = await ssn.execute(select(BC).filter(
            BC.user_id == user_id).order_by(BC.id.desc()).limit(20))
        history = history_q.scalars().all()
        await ssn.close()

    return history


async def add_new_msgs(db, text, msg_to, img):
    tz = pytz.timezone("Europe/Moscow")
    now_date = dt.datetime.now(tz=tz).strftime("%d.%m.%Y")

    async with db() as ssn:
        await ssn.merge(MessageHistory(
            date=now_date,
            msg_to=msg_to,
            text=text,
            image=img
        ))
        await ssn.commit()
        await ssn.close()


async def get_all_msg_history(db):
    async with db() as ssn:
        msgs_q = await ssn.execute(select(MessageHistory))
        msgs = msgs_q.scalars().all()
        await ssn.close()

    return msgs
