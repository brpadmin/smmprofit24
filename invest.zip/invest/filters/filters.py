from typing import Union

from aiogram import types
from aiogram.dispatcher.filters import BoundFilter
from db.models import Invester
from sqlalchemy import select


class NotBanned(BoundFilter):
    key = 'not_banned'

    async def check(self, target: Union[types.Message, types.CallbackQuery]):
        db = target.bot.get("db")

        async with db() as ssn:
            user: Invester = await ssn.get(Invester, target.from_user.id)
            if not user:
                await ssn.close()
                return True
            elif user.is_blocked == "blocked":
                await ssn.close()
                return False
            else:
                await ssn.close()
                return True


class IsAdmin(BoundFilter):
    key = 'is_admin'

    async def check(self, target: Union[types.Message, types.CallbackQuery]):
        return target.from_user.id in [5480642013]
