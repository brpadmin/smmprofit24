import asyncio
import logging
from textwrap import dedent

from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from db.models import InvestSettings, WithrawOrder
from db.queries import (change_invest_amount, change_maintentnce,
                        change_message, change_percents, change_qiwi,
                        change_qiwipay, change_wallet, change_withdraw_amount,
                        get_settings, get_stats, get_wd_info, get_wd_orders,
                        withdraw_result)
from filters.filters import IsAdmin
from keyboards.admin_keyboard import (admin_kb, admin_wd_cb, admin_wd_kb,
                                      amount_kb, change_messages_kb,
                                      change_qiwi_kb, mntc_off, mntc_on,
                                      qiwi_off, qiwi_on)
from middlewares.throttling import rate_limit
from utils.chek_pay import send_money
from utils.others import stats_text


@rate_limit(limit=1)
async def change_messages_cmd(c: types.CallbackQuery):
    txt = "💬 Выберите сообщение, которое хотите отредактировать"
    try:
        await c.message.edit_text(txt, reply_markup=change_messages_kb)
    except Exception as error:
        logging.error(
            f"Ошибка редакитрования сообщения change_messages_cmd\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def back_to_admin_menu(c: types.CallbackQuery):
    db = c.bot.get("db")
    res = await get_stats(db)
    txt = await stats_text(res)

    try:
        await c.message.edit_text(dedent(txt), reply_markup=admin_kb)
    except Exception as error:
        logging.error(
            f"Ошибка редакитрования сообщения back_to_admin_menu\n{error}")
    await c.answer()


@rate_limit(limit=1)
async def get_message_text(c: types.CallbackQuery, state: FSMContext):
    await c.message.answer("💬 Введите новый текст сообщения (Максимум 1000 символов)\n\n/cancel - отменить")
    await state.set_state("new_text")
    await state.update_data(msg=c.data)

    await c.answer()


@rate_limit(limit=1)
async def change_text(m: types.Message, state: FSMContext):
    if len(m.text.strip()) > 1000:
        await m.answer("⚠️ Длина текста не должна превышать 1000 символов")
    else:

        data = await state.get_data()
        msg = data.get("msg")
        await state.finish()

        db = m.bot.get("db")
        res = await change_message(db, msg, m.text.strip())

        if res:
            await m.answer("✅ Текст сообщения успешно изменен")

        else:
            await m.answer("⚠️ Возникла ошибка!")

        await asyncio.sleep(.2)
        txt = "💬 Выберите сообщение, которое хотите отредактировать"
        await m.answer(txt, reply_markup=change_messages_kb)


@rate_limit(limit=1)
async def change_percents_cmd(c: types.CallbackQuery, state: FSMContext):
    txt = """
    💬 Введите новые проценты для первого, второго и третьего уровней через пробел

    <i>Например: 10 5 2</i>
    
    /cancel - отмена
    """
    await c.message.answer(dedent(txt))
    await state.set_state("new_percents")

    await c.answer()


@rate_limit(limit=1)
async def set_new_percents(m: types.Message, state: FSMContext):
    percents = m.text.strip().replace(",", ".").split()

    if len(percents) != 3:
        await m.answer("⚠️ Ошибка! Проверьте правильность ввода данных\n\n/cancel - отмена")
        return

    try:
        ref_first = float(percents[0])
        ref_second = float(percents[1])
        ref_third = float(percents[2])
    except Exception as error:
        logging.error(f"Ошибка одно из чисел не может быть FLOAT\n{error}")
        await m.answer("⚠️ Ошибка! Проверьте правильность ввода данных\n\n/cancel - отмена")
        return

    if (ref_first < 0) or (ref_second < 0) or (ref_third < 0):
        await m.answer("⚠️ Ошибка! Проверьте правильность ввода данных\n\n/cancel - отмена")

    else:
        await state.finish()

        db = m.bot.get("db")
        res = await change_percents(db, ref_first, ref_second, ref_third)

        if res:
            await m.answer("✅ Реферальные проценты успешно изменены")
        else:
            await m.answer("⚠️ Возникла ошибка!")

        await asyncio.sleep(.2)
        res = await get_stats(db)
        txt = await stats_text(res)
        await m.answer(dedent(txt), reply_markup=admin_kb)


@rate_limit(limit=1)
async def change_amount_cmd(c: types.CallbackQuery):
    try:
        await c.message.edit_text("💬 Выберите, что хотите изменить", reply_markup=amount_kb)
    except Exception as error:
        logging.error(
            f"Ошибка редакитрования сообщения change_amount_cmd\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def change_invest_amount_cmd(c: types.CallbackQuery, state: FSMContext):
    txt = "💬 Введите сумму для инвестирования\n\n/cancel - отмена"
    await c.message.answer(txt)
    await state.set_state("new_amount")

    await c.answer()


@rate_limit(limit=1)
async def set_new_invest_amount(m: types.Message, state: FSMContext):
    try:
        new_amount = float(m.text.strip().replace(",", "."))
    except Exception as error:
        logging.error(f"Текст не может быть FLOAT\n{error}")
        await m.answer("Ошибка! Проверьте правильность ввода данных\n\n/cancel - отмена")
        return

    if new_amount < 0:
        await m.answer("Ошибка! Проверьте правильность ввода данных\n\n/cancel - отмена")

    else:
        await state.finish()

        db = m.bot.get("db")
        res = await change_invest_amount(db, new_amount)

        if res:
            await m.answer("✅ Новая сумма для инвестирования установлена")
        else:
            await m.answer("⚠️ Возникла ошибка!")

        await asyncio.sleep(.2)
        res = await get_stats(db)
        txt = await stats_text(res)
        await m.answer(dedent(txt), reply_markup=admin_kb)


@rate_limit(limit=1)
async def change_withdraw_amount_cmd(c: types.CallbackQuery, state: FSMContext):
    txt = "💬 Введите минимальную сумму для вывода\n\n/cancel - отмена"
    await c.message.answer(txt)
    await state.set_state("new_withdraw_amount")

    await c.answer()


@rate_limit(limit=1)
async def set_new_wd_amount(m: types.Message, state: FSMContext):
    try:
        new_amount = float(m.text.strip().replace(",", "."))
    except Exception as error:
        logging.error(f"Текст не может быть FLOAT\n{error}")
        await m.answer("Ошибка! Проверьте правильность ввода данных\n\n/cancel - отмена")
        return

    if new_amount < 0:
        await m.answer("Ошибка! Проверьте правильность ввода данных\n\n/cancel - отмена")

    else:
        await state.finish()

        db = m.bot.get("db")
        res = await change_withdraw_amount(db, new_amount)

        if res:
            await m.answer("✅ Новая минимальная сумма для вывода установлена")
        else:
            await m.answer("⚠️ Возникла ошибка!")

        await asyncio.sleep(.2)
        res = await get_stats(db)
        txt = await stats_text(res)
        await m.answer(dedent(txt), reply_markup=admin_kb)


@rate_limit(limit=1)
async def change_qiwi_cmd(c: types.CallbackQuery):
    try:
        await c.message.edit_text("💬 Выберите, что хотите изменить", reply_markup=change_qiwi_kb)
    except Exception as error:
        logging.error(
            f"Ошибка редакитрования сообщения change_qiwi_cmd\n{error}")
    await c.answer()


@rate_limit(limit=1)
async def change_qiwi_wallet_cmd(c: types.CallbackQuery, state: FSMContext):
    await c.message.answer("💬 Введите номер кошелька в формате +999999999\n\n/cancel - отмена")
    await state.set_state("qiwi_number")
    await c.answer()


@rate_limit(limit=1)
async def set_new_qiwi_wallet(m: types.Message, state: FSMContext):
    num = m.text.strip()
    if (num[0] != "+") or (not num[1:].isdigit()):
        await m.answer(
            "⚠️ Ошибка! Номер кошелька необходимо ввести в формате +999999999\n\n/cancel - отмена")

    else:
        await state.finish()

        db = m.bot.get("db")
        res = await change_wallet(db, num)

        if res:
            await m.answer(f"✅ Номер кошелька успешно изменен на {num}")

        else:
            await m.answer("⚠️ Возникла ошибка!")

        await asyncio.sleep(.2)
        await m.answer("💬 Выберите, что хотите изменить", reply_markup=change_qiwi_kb)


@rate_limit(limit=1)
async def change_qiwi_token(c: types.CallbackQuery, state: FSMContext):
    await c.message.answer("💬 Введите новый токен API или секретный ключ\n\n/cancel - отмена")
    await state.set_state("qiwi_new_token")
    await state.update_data(action=c.data)
    await c.answer()


@rate_limit(limit=1)
async def set_new_qiwi_token(m: types.Message, state: FSMContext):
    data = await state.get_data()
    action = data.get("action")
    await state.finish()

    db = m.bot.get("db")
    res = await change_qiwi(db, m.text.strip(), action)

    if res:
        if action == "qiwi_api":
            await m.answer("✅ Новый токен Qiwi API успешно установлен")
        else:
            await m.answer("✅ Новый токен Qiwi P2P успешно установлен")

    else:
        await m.answer("⚠️ Возникла ошибка!")

    await asyncio.sleep(.2)
    await m.answer("💬 Выберите, что хотите изменить", reply_markup=change_qiwi_kb)


@rate_limit(limit=1)
async def view_all_wd_orders(c: types.CallbackQuery):
    db = c.bot.get("db")
    orders = await get_wd_orders(db)

    if len(orders) == 0:
        await c.answer("⚠️ В данный момент нет заявок на вывод средств")

    else:
        order: WithrawOrder
        for order in orders:
            msg_txt = f"""
            ID - {order.user_id}
            Кошелек - <code>{order.wallet}</code>
            Сумма - {order.amount}
            """
            await c.message.answer(
                dedent(msg_txt), reply_markup=admin_wd_kb(order.id))
            await asyncio.sleep(.3)

        await c.answer()


@rate_limit(limit=1)
async def accept_wd_cmd(c: types.CallbackQuery, callback_data: dict):
    w_id = int(callback_data.get("wid"))
    action = callback_data.get("act")

    db = c.bot.get("db")
    res = await withdraw_result(db, w_id, action)

    if res:
        txt = f"✅ Заявка на вывод {res[1]}руб одобрена."

        try:
            await c.bot.send_message(res[0], txt)
            await c.message.edit_reply_markup()
            await c.answer()
        except Exception as error:
            logging.error(
                f"Ошибка отправки сообщения accept_wd_cmd\n{error}")
            await c.answer()
        logging.info(f"Заявка от {res[0]} на вывод {res[1]} одобрена")

    else:
        await c.answer("⚠️ Данная заявка больше не рассматривается")
        await c.message.edit_reply_markup()


@rate_limit(limit=1)
async def decline_wd_cmd(c: types.CallbackQuery, callback_data: dict):
    w_id = int(callback_data.get("wid"))
    action = callback_data.get("act")

    db = c.bot.get("db")
    res = await withdraw_result(db, w_id, action)

    if res:
        txt = f"❌ Заявка на вывод отклонена. {res[1]}руб возвращены на ваш баланс"

        try:
            await c.bot.send_message(res[0], txt)
            await c.message.edit_reply_markup()
            await c.answer()
        except Exception as error:
            logging.error(
                f"Ошибка отправки сообщения decline_wd_cmd\n{error}")
            await c.answer()
        logging.info(f"Заявка от {res[0]} на вывод {res[1]} отклонена")

    else:
        await c.answer("⚠️ Данная заявка больше не рассматривается")
        await c.message.edit_reply_markup()


@rate_limit(limit=1)
async def send_wd_auto(c: types.CallbackQuery, callback_data: dict):
    w_id = int(callback_data.get("wid"))

    db = c.bot.get("db")
    wallet = await get_wd_info(db, w_id)

    if wallet[2] != "cheking":
        await c.answer("⚠️ Данная заявка больше не рассматривается")
        await c.message.edit_reply_markup()
        return

    setts: InvestSettings = await get_settings(db)

    try:
        send = await send_money(
            wallet[0], wallet[1], setts.qiwi_api, setts.qiwi_wallet)
    except Exception as error:
        logging.error(f"Ошибка отправки средств автоматически\n{error}")
        await c.answer("⚠️ Ошибка отправки средств", show_alert=True)
        return

    if send:
        res = await withdraw_result(db, w_id, "accept")
        txt = f"✅ Заявка на вывод {res[1]}руб одобрена."

        try:
            await c.bot.send_message(res[0], txt)
            await c.message.edit_reply_markup()
            await c.answer("✅ Средства отправлены")
        except Exception as error:
            logging.error(
                f"Ошибка отправки сообщения send_wd_auto\n{error}")
            await c.answer()

        logging.info(f"Заявка от {res[0]} на вывод {res[1]} одобрена")

    else:
        await c.answer("⚠️ Ошибка отправки средств", show_alert=True)


@rate_limit(limit=1)
async def maintentance_cmd(c: types.CallbackQuery):
    db = c.bot.get("db")
    res: InvestSettings = await get_settings(db)

    if res.maintentance == "on":
        txt = "💬 В данный момент технические работы включены"
        await c.message.answer(txt, reply_markup=mntc_off)
    else:
        txt = "💬 В данный момент технические работы выключены"
        await c.message.answer(txt, reply_markup=mntc_on)

    await c.answer()


@rate_limit(limit=1)
async def change_maintentance_cmd(c: types.CallbackQuery):
    db = c.bot.get("db")
    res = await change_maintentnce(db, c.data)

    if res:
        if c.data == "mtns_on":
            await c.answer("⚠️ Тех работы включены ⚠️", show_alert=True)
        else:
            await c.answer("⚠️ Тех работы выключены ⚠️", show_alert=True)
    else:
        await c.answer("⚠️ Возникла ошибка")

    await c.message.delete()


@rate_limit(limit=1)
async def qiwi_cmd(c: types.CallbackQuery):
    db = c.bot.get("db")
    res: InvestSettings = await get_settings(db)

    if res.qiwi_pay == "on":
        txt = "💬 В данный момент возможность оплаты по номеру включена"
        await c.message.answer(txt, reply_markup=qiwi_off)
    else:
        txt = "💬 В данный момент возможность оплаты по номеру отключена"
        await c.message.answer(txt, reply_markup=qiwi_on)

    await c.answer()


@rate_limit(limit=1)
async def change_qiwipay_cmd(c: types.CallbackQuery):
    db = c.bot.get("db")
    res = await change_qiwipay(db, c.data)

    if res:
        if c.data == "qiwi_on":
            await c.answer("⚠️ Возможность оплаты по номеру включена", show_alert=True)
        else:
            await c.answer("⚠️ Возможность оплаты по номеру отключена", show_alert=True)
    else:
        await c.answer("⚠️ Возникла ошибка")

    await c.message.delete()


def admin_handlers(dp: Dispatcher):
    dp.register_callback_query_handler(
        change_messages_cmd, IsAdmin(), text="change_msgs")
    dp.register_callback_query_handler(
        back_to_admin_menu, IsAdmin(), text="to_admin")

    dp.register_callback_query_handler(
        get_message_text, IsAdmin(), text=["change_hello", "change_proj", "change_info"])
    dp.register_message_handler(change_text, IsAdmin(), state="new_text")

    dp.register_callback_query_handler(
        change_percents_cmd, IsAdmin(), text="change_percents")
    dp.register_message_handler(
        set_new_percents, IsAdmin(), state="new_percents")

    dp.register_callback_query_handler(
        change_amount_cmd, IsAdmin(), text="change_amount")
    dp.register_callback_query_handler(
        change_invest_amount_cmd, IsAdmin(), text="invest_amount")
    dp.register_message_handler(
        set_new_invest_amount, IsAdmin(), state="new_amount")
    dp.register_callback_query_handler(
        change_withdraw_amount_cmd, IsAdmin(), text="withdraw_amount")
    dp.register_message_handler(
        set_new_wd_amount, IsAdmin(), state="new_withdraw_amount")

    dp.register_callback_query_handler(
        change_qiwi_cmd, IsAdmin(), text="change_qiwi")
    dp.register_callback_query_handler(
        change_qiwi_wallet_cmd, IsAdmin(), text="qiwi_wlt")
    dp.register_message_handler(
        set_new_qiwi_wallet, IsAdmin(), state="qiwi_number")
    dp.register_callback_query_handler(
        change_qiwi_token, IsAdmin(), text=["qiwi_ptp", "qiwi_api"])
    dp.register_message_handler(
        set_new_qiwi_token, IsAdmin(), state="qiwi_new_token")

    dp.register_callback_query_handler(
        view_all_wd_orders, IsAdmin(), text="wd_orders")
    dp.register_callback_query_handler(
        accept_wd_cmd, IsAdmin(), admin_wd_cb.filter(act="accept"))
    dp.register_callback_query_handler(
        decline_wd_cmd, IsAdmin(), admin_wd_cb.filter(act="decline"))
    dp.register_callback_query_handler(
        send_wd_auto, IsAdmin(), admin_wd_cb.filter(act="auto"))

    dp.register_callback_query_handler(
        maintentance_cmd, IsAdmin(), text="maintentance")
    dp.register_callback_query_handler(
        change_maintentance_cmd, IsAdmin(), Text(startswith="mtns_o"))

    dp.register_callback_query_handler(
        qiwi_cmd, IsAdmin(), text="on_off_wallet_pay")
    dp.register_callback_query_handler(
        change_qiwipay_cmd, IsAdmin(), text=["qiwi_on", "qiwi_off"])
