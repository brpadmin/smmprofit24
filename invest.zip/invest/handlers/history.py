import asyncio
import logging
from textwrap import dedent

from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from db.models import BalanceChange, Invester, InvestSettings
from db.queries import (create_withdraw_order, dividends_to_many,
                        dividends_to_one, get_histrory, get_profile,
                        get_settings, get_stats, get_wd_user_id,
                        user_get_history)
from filters.filters import IsAdmin, NotBanned
from keyboards.admin_keyboard import (admin_kb, admin_wd_cb, admin_wd_kb,
                                      close_btn, div_cb, div_kb, minus_cb,
                                      minus_kb)
from keyboards.keyboars import back_btn, investor_kb, wd_type_kb
from middlewares.throttling import rate_limit
from utils.others import get_user_history, stats_text


@rate_limit(limit=1)
async def user_balance_history_cmd(c: types.CallbackQuery, state: FSMContext):
    txt = "💬 Введите ID\n\n/cancel - отмена"
    await c.message.answer(txt)
    await state.set_state("id_for_history")
    await state.update_data(action=c.data)
    await c.answer()


@rate_limit(limit=1)
async def send_user_balance(m: types.Message, state: FSMContext):
    if not m.text.strip().isdigit():
        await m.answer("⚠️ ID необходимо ввести цифрами\n\n/cancel - отмена")
        return
    data = await state.get_data()
    action = data.get("action")
    await state.finish()

    db = m.bot.get("db")
    his = await get_histrory(db, int(m.text.strip()))

    if his:
        if len(his) == 0:
            await m.answer("⚠️ История баланса пользователя пуста")
            return

        if action == "admin_bal_history_m":
            his_txt = ""
            item: BalanceChange
            for item in his:
                if item.change_from == "ref":
                    his_txt += f"\n\n[{item.date_str}]\n+{item.amount}руб за реферала {item.ref_lvl}ур {item.ref_name}"
                elif item.change_from == "user":
                    his_txt += f"\n\n[{item.date_str}]\n-{item.amount}руб вывод средств"
                else:
                    if item.change_type == "out":
                        his_txt += f"\n\n[{item.date_str}]\n-{item.amount}руб списание администрацией"
                    else:
                        his_txt += f"\n\n[{item.date_str}]\n+{item.amount}руб пополнение администрацией"

                if len(his_txt) > 3800:
                    await m.answer(his_txt, reply_markup=close_btn)
                    his_txt = ""

            if his_txt:
                await m.answer(his_txt, reply_markup=close_btn)

        else:
            file_his = await get_user_history(his)

            if file_his:
                await m.answer_document(types.InputFile("files/user_history.xlsx"))
            else:
                await m.answer("⚠️ Произошла ошибка")

    else:
        await m.answer("⚠️ Ошибка! Возможно такой пользователь не найден в базе")

    await asyncio.sleep(.1)
    res = await get_stats(db)
    txt = await stats_text(res)

    await m.answer(dedent(txt), reply_markup=admin_kb)


@rate_limit(limit=1)
async def view_user_his_from_wd(c: types.CallbackQuery, callback_data: dict):
    w_id = int(callback_data.get("wid"))

    db = c.bot.get("db")
    user_id = await get_wd_user_id(db, w_id)
    his = await get_histrory(db, user_id)

    if len(his) == 0:
        await c.answer("⚠️ История баланса пользователя пуста")
        return

    his_txt = ""
    item: BalanceChange
    for item in his:
        if item.change_from == "ref":
            his_txt += f"\n\n[{item.date_str}]\n+{item.amount}руб за реферала {item.ref_lvl}ур {item.ref_name}"
        elif item.change_from == "user":
            his_txt += f"\n\n[{item.date_str}]\n-{item.amount}руб вывод средств"
        else:
            if item.change_type == "out":
                his_txt += f"\n\n[{item.date_str}]\n-{item.amount}руб списание администрацией"
            else:
                his_txt += f"\n\n[{item.date_str}]\n+{item.amount}руб пополнение администрацией"

        if len(his_txt) > 3800:
            await c.message.answer(his_txt, reply_markup=close_btn)
            his_txt = ""

    if his_txt:
        await c.message.answer(his_txt, reply_markup=close_btn)

    await c.answer()


@rate_limit(limit=1)
async def view_my_history(c: types.CallbackQuery):
    db = c.bot.get("db")
    his = await user_get_history(db, c.from_user.id)

    if len(his) == 0:
        await c.answer("⚠️ История баланса пуста")
    else:
        his_txt = "Последние 20 записей:"
        item: BalanceChange
        for item in his:
            if item.change_from == "ref":
                his_txt += f"\n\n[{item.date_str}]\n+{item.amount}руб за реферала {item.ref_lvl}ур {item.ref_name}"
            elif item.change_from == "user":
                his_txt += f"\n\n[{item.date_str}]\n-{item.amount}руб вывод средств"
            else:
                if item.change_type == "out":
                    his_txt += f"\n\n[{item.date_str}]\n-{item.amount}руб списание администрацией"
                else:
                    his_txt += f"\n\n[{item.date_str}]\n+{item.amount}руб пополнение администрацией"

        await c.message.answer(his_txt, reply_markup=close_btn)

    await c.answer()


@rate_limit(limit=1)
async def minus_balance_cmd(c: types.CallbackQuery):
    txt = "💬 Выберите кому хотите списать баланс"

    try:
        await c.message.edit_text(txt, reply_markup=minus_kb)
    except Exception as error:
        logging.error(
            f"Ошибка редакитрования сообщения minus_balance_cmd\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def minus_to_one_cmd(c: types.CallbackQuery, state: FSMContext):
    txt = "💬 Введите ID инвестора\n\n/cancel - отмена"
    await c.message.answer(txt)
    await state.set_state("id_for_minus_b")
    await c.answer()


@rate_limit(limit=1)
async def amount_minus_to_one(m: types.Message, state: FSMContext):
    if not m.text.strip().isdigit():
        await m.answer("⚠️ ID необходимо ввести цифрами\n\n/cancel - отмена")
    else:
        await m.answer("💬 Введите сумму\n\n/cancel - отмена")
        await state.set_state("amount_minus_for_one")
        await state.update_data(user_id=m.text.strip())


@rate_limit(limit=1)
async def minus_bal_to_one(m: types.Message, state: FSMContext):
    try:
        amount = float(m.text.strip().replace(",", "."))
    except Exception as error:
        logging.error(f"Ошибка! {m.text} не может быть FLOAT\n{error}")
        await m.answer("⚠️ Ошибка! Введите сумму цифрами\n\n/cancel - отмена")
        return

    data = await state.get_data()
    user_id = int(data.get("user_id"))

    await state.finish()

    db = m.bot.get("db")
    res = await dividends_to_one(db, user_id, amount, "minus")

    if res:
        await m.answer(f"✅ Инвестору {user_id} списано с баланса {amount}руб")

        await asyncio.sleep(.1)

        logging.info(f"Пользователю {user_id} списано {amount}руб")

    else:
        await m.answer("⚠️ Возникла ошибка")

    await asyncio.sleep(.1)

    txt = "💬 Выберите кому хотите списать баланс"
    await m.answer(txt, reply_markup=minus_kb)


@rate_limit(limit=1)
async def minus_to_many_cmd(c: types.CallbackQuery, state: FSMContext, callback_data: dict):
    count = int(callback_data.get("count"))
    await c.message.answer("💬 Введите сумму\n\n/cancel - отмена")
    await state.set_state("minus_to_many")
    await state.update_data(count=count)
    await c.answer()


@rate_limit(limit=1)
async def minus_bal_to_many(m: types.Message, state: FSMContext):
    try:
        amount = float(m.text.strip().replace(",", "."))
    except Exception as error:
        logging.error(f"Ошибка! {m.text} не может быть FLOAT\n{error}")
        await m.answer("⚠️ Ошибка! Введите сумму цифрами\n\n/cancel - отмена")
        return

    data = await state.get_data()
    count = int(data.get("count"))

    await state.finish()

    await m.answer_chat_action("typing")

    db = m.bot.get("db")
    invs = await dividends_to_many(db, count, amount, "minus")

    if invs:
        await m.answer("✅ Списание средств завершено")
        logging.info(f"Инвесторам списано по {amount}руб")
    else:
        await m.answer("⚠️ Ошибка! Возможно список инвесторов пуст")

    await asyncio.sleep(.1)

    txt = "💬 Выберите кому хотите списать баланс"
    await m.answer(txt, reply_markup=minus_kb)


def history_handlers(dp: Dispatcher):
    dp.register_callback_query_handler(
        user_balance_history_cmd, IsAdmin(), text=["admin_bal_history_m", "admin_bal_history_f"])
    dp.register_message_handler(
        send_user_balance, IsAdmin(), state="id_for_history")
    dp.register_callback_query_handler(
        view_user_his_from_wd, IsAdmin(), admin_wd_cb.filter(act="hist"))
    dp.register_callback_query_handler(
        view_my_history, NotBanned(), text="user_bal_history")

    dp.register_callback_query_handler(
        minus_balance_cmd, IsAdmin(), text="minus_balance")
    dp.register_callback_query_handler(
        minus_to_one_cmd, IsAdmin(), text="minus_bal_id")
    dp.register_message_handler(
        amount_minus_to_one, IsAdmin(), state="id_for_minus_b")
    dp.register_message_handler(
        minus_bal_to_one, IsAdmin(), state="amount_minus_for_one")
    dp.register_callback_query_handler(
        minus_to_many_cmd, IsAdmin(), minus_cb.filter())
    dp.register_message_handler(
        minus_bal_to_many, IsAdmin(), state="minus_to_many")
