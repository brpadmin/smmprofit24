import logging
import random
from textwrap import dedent

from aiogram import Dispatcher, types
from db.models import InvestSettings
from db.queries import (add_new_invest, confirmed_invest, get_bot_wallet,
                        get_invest_id_info, get_settings)
from filters.filters import NotBanned
from keyboards.keyboars import (bill_cb, bill_kb, invest_kb, invest_ptp_kb,
                                investor_kb, paid_btn, paid_cb)
from middlewares.throttling import rate_limit
from utils.chek_pay import (check_bill_for_pay, check_wallet_pay,
                            create_new_bill)


@rate_limit(limit=1)
async def invest_to_project(c: types.CallbackQuery):
    db = c.bot.get("db")
    res: InvestSettings = await get_settings(db)

    if res.maintentance == "on":
        await c.answer("⚠️ В данный момент оплата недоступна. Попробуйте позже")
        return

    txt = """
    💬 Сервис работает через QIWI!
    Вывод средств автоматический!\n
    Для других способов вывода (не QIWI), Свяжитесь с Тех-Поддержкой!\n
    Профит пользователя в сутки <b>~120 руб</b>\n
    Проект стремительно развивается!\n

    Вся прибыль проекта распределяется между участниками!
    На средства с подписки, потдерживается и расширяется наше сообщество!
    Также подписка работает как антибот*, так в боте будут только реальные люди!


    <b>Благодарим всех кто с нами!</b>
    <b>С Ув. Команда SMM PROFIT BOT</b>

    """
    img = types.InputFile("img/invest.png")
    media = types.InputMedia(caption=dedent(txt), media=img)
    try:
        if res.qiwi_pay == "on":
            await c.message.edit_media(media, reply_markup=invest_kb)
        else:
            await c.message.edit_media(media, reply_markup=invest_ptp_kb)
    except Exception as error:
        logging.error(
            f"Ошибка редактирования медиа invest_to_project\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def pay_wallet_cmd(c: types.CallbackQuery):
    db = c.bot.get("db")
    res: InvestSettings = await get_settings(db)

    if res.maintentance == "on":
        await c.answer("⚠️ В данный момент оплата недоступна. Попробуйте позже")
        return

    code = random.randint(100000, 999999)
    wallet = await get_bot_wallet(db)
    invest_id = await add_new_invest(db, c.from_user.id, wallet[1], code, str(code))

    txt = f"""
    Нажмите на номер или коментарий чтобы скопировать!\n
    Стоимость: <b>{wallet[1]}</b> рублей\n
    QIWI счет: <code>{wallet[0]}</code>
    Коментарий к оплате: <code>{code}</code>
    \n

    ⚠️ <u>После оплаты ОБЯЗАТЕЛЬНО нажмите кнопку <b>Я оплатил(а)</b></u>
    """
    try:
        await c.message.edit_caption(dedent(txt), reply_markup=paid_btn(invest_id, "wallet"))
    except Exception as error:
        logging.error(
            f"Ошибка редактирования текста pay_wallet_cmd\n{error}")

    await c.answer()


@rate_limit(limit=2)
async def confirm_pay(c: types.CallbackQuery, callback_data: dict):
    db = c.bot.get("db")
    res: InvestSettings = await get_settings(db)

    if res.maintentance == "on":
        await c.answer("⚠️ В данный момент оплата недоступна. Попробуйте позже")
        return

    await c.message.answer_chat_action("typing")

    invest_id = int(callback_data.get("ord_id"))

    db = c.bot.get("db")
    res = await get_invest_id_info(db, invest_id)
    check_for_pay = await check_wallet_pay(res[0], res[1], res[2], res[3])

    if check_for_pay:
        res = await confirmed_invest(db, invest_id)

        if res:
            await c.answer("✅ Оплата успешно подтверждена. Вы стали инвестором проекта")
            img = types.InputFile("img/start.png")
            txt = "Вы находитесь в главном меню. Выберите интересующую вас информацию"
            await c.message.answer_photo(img, txt, reply_markup=investor_kb)
            logging.info(f"Пользователь {c.from_user.id} стал инвестором")

        else:
            await c.answer("⚠️ Ошибка! Возможно эта заявка уже оплачена")

        try:
            await c.message.edit_reply_markup()
        except Exception as error:
            logging.error(
                f"Ошибка удаления клавиатуры при проверке оплаты\n{error}")
    else:
        await c.answer(
            "⚠️ Ваша оплата не найдена или сумма платежа меньше необходимой. Убедитесь, что вы указали комментарий", show_alert=True)


@rate_limit(limit=1)
async def pay_invoice_cmd(c: types.CallbackQuery):
    db = c.bot.get("db")
    res: InvestSettings = await get_settings(db)

    if res.maintentance == "on":
        await c.answer("⚠️ В данный момент оплата недоступна. Попробуйте позже")
        return

    code = random.randint(100000, 999999)
    bill = await create_new_bill(res.invest_amount, code, res.qiwi_ptp)
    inv_id = await add_new_invest(db, c.from_user.id, res.invest_amount, code, bill[0])

    txt = f"""
    Вам необходимо оплатить <b>{res.invest_amount}</b> рублей
    <a href='{bill[1]}'>Ссылка для оплаты</a>
    Или можете перейти к оплате нажатием на кнопку ниже

    ⚠️ <u>После оплаты ОБЯЗАТЕЛЬНО нажмите кнопку <b>Я оплатил</b></u>

    """
    try:
        await c.message.edit_caption(dedent(txt), reply_markup=bill_kb(inv_id, bill[0], bill[1]))
    except Exception as error:
        logging.error(
            f"Ошибка редактирования текста pay_invoice_cmd\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def confirm_bill(c: types.CallbackQuery, callback_data: dict):
    bill_id = callback_data.get("b_id")
    invest_id = int(callback_data.get("i_id"))

    db = c.bot.get("db")
    setts: InvestSettings = await get_settings(db)

    res = await check_bill_for_pay(bill_id, setts.qiwi_ptp)
    if res:
        new_inv = await confirmed_invest(db, invest_id)

        if new_inv:
            await c.answer("✅ Оплата успешно подтверждена. Вы стали инвестором проекта")
            img = types.InputFile("img/start.png")
            txt = "Вы находитесь в главном меню. Выберите интересующую вас информацию"
            await c.message.answer_photo(img, txt, reply_markup=investor_kb)
            logging.info(f"Пользователь {c.from_user.id} стал инвестором")

        else:
            await c.answer("⚠️ Ошибка! Возможно эта заявка уже оплачена")

        try:
            await c.message.edit_reply_markup()
        except Exception as error:
            logging.error(
                f"Ошибка удаления клавиатуры при проверке оплаты\n{error}")

    else:
        await c.answer(
            "⚠️ Счет не оплачен!", show_alert=True)


def invest_handlers(dp: Dispatcher):
    dp.register_callback_query_handler(
        invest_to_project, NotBanned(), text="invest")
    dp.register_callback_query_handler(
        pay_wallet_cmd, NotBanned(), text="pay_wallet")
    dp.register_callback_query_handler(
        confirm_pay, NotBanned(), paid_cb.filter(method="wallet"))
    dp.register_callback_query_handler(
        pay_invoice_cmd,  NotBanned(), text="pay_p2p")
    dp.register_callback_query_handler(
        confirm_bill, NotBanned(), bill_cb.filter())
