import asyncio
import logging
from textwrap import dedent

from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from db.models import Invester, WithrawOrder
from db.queries import (add_new_msgs, block_list_db, change_invest_amount,
                        change_message, change_percents, change_qiwi,
                        get_all_blocked, get_all_investors,
                        get_all_msg_history, get_all_users, get_profile,
                        get_referrals, get_stats, get_user_id_from_wd,
                        get_users_for_msgs, get_wd_orders, withdraw_result)
from filters.filters import IsAdmin
from keyboards.admin_keyboard import (admin_kb, admin_wd_cb, admin_wd_kb,
                                      bl_kb, change_messages_kb, close_btn,
                                      inv_list_kb, msgs_kb, user_list_kb)
from keyboards.keyboars import back_btn, investor_kb, start_kb
from middlewares.throttling import rate_limit
from sqlalchemy import update
from utils.others import get_msg_history, get_users_file, stats_text


@rate_limit(limit=1)
async def user_list_cmd(c: types.CallbackQuery):
    await c.message.edit_text("💬 Как именно хотите получить информацию?", reply_markup=user_list_kb)
    await c.answer()


@rate_limit(limit=1)
async def user_list_msg(c: types.CallbackQuery):
    db = c.bot.get("db")
    users = await get_all_users(db)

    if len(users) == 0:
        await c.answer("⚠️ Список пользователей пуст")
        return

    if c.data == "users_in_msg":

        msg_text = ""
        user: Invester
        for user in users:
            msg_text += f"\nID:<code>{user.id}</code> - {user.username} - Рефералов: {user.ref_count}\nЗаработано: {user.total_ref_cash} - Баланс: {user.balance} - Выведено: {user.total_ref_cash - user.balance}"

            if len(msg_text) > 3500:
                await c.message.answer(msg_text)
                msg_text = ""
                await asyncio.sleep(.1)

        if msg_text:
            await c.message.answer(msg_text)
        await c.answer()

    else:
        await c.message.answer_chat_action("upload_document")
        res = await get_users_file(users, "user_list")

        if res:
            await c.message.answer_document(types.InputFile("files/user_list.xlsx"))
            await c.answer()
        else:
            await c.answer("⚠️ Возникла ошибка!")

    await asyncio.sleep(.1)
    await c.message.answer("💬 Как именно хотите получить информацию?", reply_markup=user_list_kb)


@rate_limit(limit=1)
async def investor_list_cmd(c: types.CallbackQuery):
    await c.message.edit_text("💬 Как именно хотите получить информацию?", reply_markup=inv_list_kb)
    await c.answer()


@rate_limit(limit=1)
async def investor_list_msg(c: types.CallbackQuery):
    db = c.bot.get("db")
    investors = await get_all_investors(db, c.data)

    if len(investors) == 0:
        await c.answer("⚠️ Список пользователей пуст")
        return

    call_data = c.data
    if call_data.split("_")[-1] == "msg":

        msg_text = ""
        inv: Invester
        for inv in investors:
            msg_text += f"\nID:<code>{inv.id}</code> - {inv.username} - Рефералов: {inv.ref_count}\nЗаработано: {inv.total_ref_cash} - Баланс: {inv.balance} - Выведено: {inv.total_ref_cash - inv.balance}"

            if len(msg_text) > 3500:
                await c.message.answer(msg_text)
                msg_text = ""
                await asyncio.sleep(.1)

        if msg_text:
            await c.message.answer(msg_text)

        await c.answer()

    else:
        await c.message.answer_chat_action("upload_document")
        res = await get_users_file(investors, c.data)

        if res:
            await c.message.answer_document(types.InputFile(f"files/{c.data}.xlsx"))
            await c.answer()
        else:
            await c.answer("⚠️ Возникла ошибка!")

    await asyncio.sleep(.1)
    await c.message.answer("💬 Как именно хотите получить информацию?", reply_markup=inv_list_kb)


@rate_limit(limit=1)
async def block_list_cmd(c: types.CallbackQuery):
    db = c.bot.get("db")
    users = await get_all_blocked(db)

    if len(users) == 0:
        txt = "💬 В данный момент список заблокированных пользователей пуст"
        await c.message.answer(txt, reply_markup=bl_kb)

    else:
        txt = ""
        user: Invester
        for user in users:
            txt += f"\nID:<code>{user.id}</code> - {user.username}"

            if len(txt) > 3800:
                await c.message.answer(txt)
                txt = ""
                await asyncio.sleep(.1)

        if txt:
            await c.message.answer(txt, reply_markup=bl_kb)
        else:
            await c.message.answer("💬 Выберите действие по кнопкам ниже", reply_markup=bl_kb)

    await c.answer()


@rate_limit(limit=1)
async def block_list_commads(c: types.CallbackQuery, state: FSMContext):
    await c.message.answer("💬 Введите ID пользователя\n\n/cancel - отменить")
    await state.set_state("waiting_for_userid")
    await state.update_data(action=c.data)
    await c.answer()


@rate_limit(limit=1)
async def block_list_id(m: types.Message, state: FSMContext):
    if not m.text.strip().isdigit():
        await m.answer("⚠️ Введите ID цифрами\n\n/cancel - отменить")

    else:
        data = await state.get_data()
        action = data.get("action")
        await state.finish()

        db = m.bot.get("db")
        res = await block_list_db(db, action, int(m.text.strip()))

        if res:
            if action == "give_access":
                await m.answer(f"✅ Пользователю {m.text} предоставлен доступ")
                logging.info(
                    f"Пользователю {m.text} предоставлен статус инвестора админом")
            elif action == "add_to_bl":
                await m.answer(f"✅ Пользователь {m.text} добавлен в ЧС")
                logging.info(f"Пользователь {m.text} добавлен в ЧС")
            else:
                await m.answer(f"✅ Пользователь {m.text} убран из ЧС")
                logging.info(f"Пользователь {m.text} удален из ЧС")

        else:
            await m.answer("⚠️ Возникла ошибка!")

    await asyncio.sleep(.1)
    res = await get_stats(db)
    txt = await stats_text(res)
    await m.answer(dedent(txt), reply_markup=admin_kb)


@rate_limit(limit=1)
async def msg_to_all_cmd(c: types.CallbackQuery):
    await c.message.edit_text(
        "💬 Выберите группу пользователей, для которой будет создана рассылка", reply_markup=msgs_kb)
    await c.answer()


@rate_limit(limit=1)
async def get_msg_content(c: types.CallbackQuery, state: FSMContext):
    await c.message.answer("💬 Введите текст сообщения\n\n/cancel - отменить")
    await state.set_state("wait_for_msg_content")
    await state.update_data(action=c.data)
    await c.answer()


@rate_limit(limit=1)
async def send_messages_to_users(m: types.Message, state: FSMContext):
    data = await state.get_data()
    action = data.get("action")
    await state.finish()

    db = m.bot.get("db")
    users = await get_users_for_msgs(db, action)

    user: Invester
    for user in users:
        try:
            if m.caption:
                await m.copy_to(user.id, caption=m.caption)
            else:
                await m.copy_to(user.id)
        except Exception as error:
            logging.error(
                f"Ошибка отправки сообщения пользователю {user.id}\n{error}")
        await asyncio.sleep(.15)

    await m.answer("✅ Рассылка завершена")
    logging.info("Рассылка завершена")

    if m.photo:
        text = m.caption or "Без текста"
        img = "С изображенем"
    else:
        text = m.text
        img = "Текст"

    if action == "msgs_to_novice":
        msg_to = "Новичкам"
    elif action == "msgs_to_invs":
        msg_to = "Инвесторам"
    else:
        msg_to = "Всем"

    await add_new_msgs(db, text, msg_to, img)

    await asyncio.sleep(.1)
    await m.answer("💬 Выберите группу пользователей, для которой будет создана рассылка", reply_markup=msgs_kb)


@rate_limit(limit=1)
async def get_msg_history_file(c: types.CallbackQuery):
    db = c.bot.get("db")
    data = await get_all_msg_history(db)

    if data:
        await get_msg_history(data)

        await c.message.answer_document(types.InputFile("files/messages_history.xlsx"))
        await c.answer()
    else:
        await c.answer("⚠️ Ошибка! Возможно, история рассылок пуста")

    await asyncio.sleep(.1)
    await c.message.answer("💬 Выберите группу пользователей, для которой будет создана рассылка", reply_markup=msgs_kb)


@rate_limit(limit=1)
async def id_info_cmd(c: types.CallbackQuery, state: FSMContext):
    await c.message.answer("💬 Введите ID пользователя\n\n/cancel - отмена")
    await state.set_state("waiting_for_id_info")
    await c.answer()


@rate_limit(limit=1)
async def send_user_info(m: types.Message, state: FSMContext):
    if not m.text.strip().isdigit():
        await m.answer("⚠️ Ошибка! Введите ID цифрами\n\n/cancel - отмена")
        return

    await state.finish()
    db = m.bot.get("db")
    user: Invester = await get_profile(db, int(m.text.strip()))

    if user:
        if user.status == "investor":
            status = "Инвестор"
        else:
            status = "None"

        txt = f"""
        Имя - {user.username}
        ID - {user.id}
        Статус - {status}

        Количество приглашенных:
        Всего - {user.ref_count}
        Инвесторов - {user.active_refs}

        Общая прибыль: {user.total_ref_cash}руб
        Текущий баланс: {user.balance}руб
        """
        await m.answer(dedent(txt), reply_markup=close_btn)
        await asyncio.sleep(.1)

        users = await get_referrals(db, int(m.text.strip()))

        if len(users[0]) == 0:
            await m.answer(
                "⚠️ У этого пользователя нет не купивших доступ пользователей", reply_markup=close_btn)
        else:
            users_txt = "Приглашенные пользователи:"

            user: Invester
            for user in users[0]:
                users_txt += f"\nID: {user.id} - {user.username}"

                if len(users_txt) >= 3800:
                    await m.answer(users_txt, reply_markup=close_btn)
                    users_txt = ""

            if len(users_txt) > 0:
                await m.answer(users_txt, reply_markup=close_btn)
            await asyncio.sleep(.1)

        if len(users[1]) == 0:
            await m.answer(
                "⚠️ У этого пользователя нет купивших доступ пользователей", reply_markup=close_btn)
        else:
            inv_txt = "Приглашенные инвесторы:"

            inv: Invester
            for inv in users[1]:
                inv_txt += f"\nID: {inv.id} - {inv.username}"

                if len(inv_txt) >= 3800:
                    await m.answer(inv_txt, reply_markup=close_btn)
                    inv_txt = ""

            if len(inv_txt) > 0:
                await m.answer(inv_txt, reply_markup=close_btn)

    else:
        await m.answer("⚠️ Пользователь с таким ID не найден в базе", reply_markup=close_btn)

    await asyncio.sleep(.1)
    await m.answer("💬 Выберите действие по кнопкам ниже", reply_markup=bl_kb)


@rate_limit(limit=1)
async def id_info_from_wd(c: types.CallbackQuery, callback_data: dict):
    w_id = int(callback_data.get("wid"))

    db = c.bot.get("db")
    user_id = await get_user_id_from_wd(db, w_id)

    user: Invester = await get_profile(db, user_id)

    if user.status == "investor":
        status = "Инвестор"
    else:
        status = "None"

    txt = f"""
    Имя - {user.username}
    ID - {user.id}
    Статус - {status}

    Количество приглашенных:
    Всего - {user.ref_count}
    Инвесторов - {user.active_refs}

    Общая прибыль: {user.total_ref_cash}руб
    Текущий баланс: {user.balance}руб
    """
    await c.message.answer(dedent(txt), reply_markup=close_btn)
    await asyncio.sleep(.1)

    users = await get_referrals(db, user_id)

    if len(users[0]) == 0:
        await c.message.answer(
            "⚠️ У этого пользователя нет не купивших доступ пользователей", reply_markup=close_btn)
    else:
        users_txt = "Приглашенные пользователи:"

        user: Invester
        for user in users[0]:
            users_txt += f"\nID: {user.id} - {user.username}"

            if len(users_txt) >= 3800:
                await c.message.answer(users_txt, reply_markup=close_btn)
                users_txt = ""

        if len(users_txt) > 0:
            await c.message.answer(users_txt, reply_markup=close_btn)
        await asyncio.sleep(.1)

    if len(users[1]) == 0:
        await c.message.answer(
            "⚠️ У этого пользователя нет купивших доступ пользователей", reply_markup=close_btn)
    else:
        inv_txt = "Приглашенные инвесторы:"

        inv: Invester
        for inv in users[1]:
            inv_txt += f"\nID: {inv.id} - {inv.username}"

            if len(inv_txt) >= 3800:
                await c.message.answer(inv_txt, reply_markup=close_btn)
                inv_txt = ""

        if len(inv_txt) > 0:
            await c.message.answer(inv_txt, reply_markup=close_btn)

    await c.answer()


def users_handlers(dp: Dispatcher):
    dp.register_callback_query_handler(
        user_list_cmd, IsAdmin(), text="user_list")
    dp.register_callback_query_handler(
        user_list_msg, IsAdmin(), text=["users_in_msg", "users_in_xlsx"])
    dp.register_callback_query_handler(
        investor_list_cmd, IsAdmin(), text="invest_list")
    dp.register_callback_query_handler(
        investor_list_msg, IsAdmin(), Text(startswith="inv_"))
    dp.register_callback_query_handler(
        block_list_cmd, IsAdmin(), text="block_list")
    dp.register_callback_query_handler(block_list_commads, IsAdmin(), text=[
                                       "add_to_bl", "del_from_bl", "give_access"])
    dp.register_message_handler(
        block_list_id, IsAdmin(), state="waiting_for_userid")
    dp.register_callback_query_handler(
        msg_to_all_cmd, IsAdmin(), text="create_msgs")
    dp.register_callback_query_handler(
        get_msg_content, IsAdmin(), Text(startswith="msgs_to_"))
    dp.register_message_handler(
        send_messages_to_users, IsAdmin(), content_types="any", state="wait_for_msg_content")
    dp.register_callback_query_handler(
        get_msg_history_file, IsAdmin(), text="msg_history_file")

    dp.register_callback_query_handler(id_info_cmd, IsAdmin(), text="id_info")
    dp.register_message_handler(
        send_user_info, IsAdmin(), state="waiting_for_id_info")
    dp.register_callback_query_handler(
        id_info_from_wd, IsAdmin(), admin_wd_cb.filter(act="info"))
