import asyncio
import logging
from textwrap import dedent

from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from db.models import Invester, InvestSettings
from db.queries import (add_new_msgs, create_withdraw_order, dividends_to_many,
                        dividends_to_one, get_profile, get_settings)
from filters.filters import IsAdmin, NotBanned
from keyboards.admin_keyboard import admin_wd_kb, div_cb, div_kb
from keyboards.keyboars import back_btn, investor_kb, wd_type_kb
from middlewares.throttling import rate_limit


@rate_limit(limit=1)
async def withdraw_cmd(c: types.CallbackQuery):
    img = types.InputFile("img/withdraw.png")
    media = types.InputMedia(media=img)
    try:
        await c.message.edit_media(media, reply_markup=wd_type_kb)
    except Exception as error:
        logging.error(f"Ошибка редакитрования медиа withdraw_cmd\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def withdraw_other_cmd(c: types.CallbackQuery):
    db = c.bot.get("db")
    setts: InvestSettings = await get_settings(db)

    txt = f"""
    Если вы желаете сделать вывод другими способами, напишите в Тех-Поддержку
    Потдерживаемые способы можете увидеть ниже

    Криптовалюты:
    BITCOIN
    BitcoinCash
    Tron 
    USDT
    Etherium
    Litecoin

    Банки:
    Сбербанк
    ПриватБанк
    МоноБанк
    Тинькофф


    Минимальная сумма вывода в эквиваленте рубли уточняйте в Тех-Поддержке, так как это зависит от способа вывода!
    Для QIWI минимальная: {setts.withdraw_amount}руб
    """

    try:
        await c.message.edit_caption(dedent(txt), reply_markup=back_btn)
    except Exception as error:
        logging.error(
            f"Ошибка редакитрования текста withdraw_other_cmd\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def withdraw_qiwi_cmd(c: types.CallbackQuery, state: FSMContext):
    db = c.bot.get("db")
    user: Invester = await get_profile(db, c.from_user.id)
    res: InvestSettings = await get_settings(db)

    if user.withdraw != "allowed":
        await c.answer("Вы уже отправили заявку на вывод средств")
        return

    if res.withdraw_amount > user.balance:
        await c.answer(
            f"Недостаточно средств!\nМинимальная сумма для вывода - {res.withdraw_amount}руб", show_alert=True)
        return

    txt = f"""
    Текущий баланс: {user.balance}

    Введите сумму, которую хотите вывести

    /cancel - отмена
    """
    await c.message.answer(dedent(txt))
    await state.set_state("withdraw_amount")
    await state.update_data(balance=user.balance)
    await c.answer()


@rate_limit(limit=1)
async def get_wallet(m: types.Message, state: FSMContext):
    try:
        amount = float(m.text.strip().replace(",", "."))
    except Exception as error:
        logging.error(f"Ошибка. {m.text.strip()} не может быть FLOAT\n{error}")
        await m.answer("⚠️ Ошибка. Попробуйте еще\n\n/cancel - отмена")
        return

    data = await state.get_data()
    balance = float(data.get("balance"))
    if amount < 0:
        await m.answer("⚠️ Число должно быть больше 0\n\n/cancel - отмена")

    elif amount > balance:
        await m.answer("⚠️ На балансе недостаточно средств\n\n/cancel - отмена")

    else:
        await m.answer("💬 Введите ваш кошелек QIWI в формате +999999999\n\n/cancel - отмена")
        await state.set_state("wallet_for_withdraw")
        await state.update_data(amount=amount)


@rate_limit(limit=1)
async def new_withdraw(m: types.Message, state: FSMContext):
    wallet = m.text.strip()

    if (wallet[0] != "+") or (not wallet[1:].isdigit()):
        await m.answer(
            "⚠️ Ошибка! Номер кошелька необходимо ввести в формате +999999999\n\n/cancel - отмена")
        return

    data = await state.get_data()
    amount = float(data.get("amount"))

    await state.finish()

    db = m.bot.get("db")
    res = await create_withdraw_order(db, m.from_user.id, amount, m.from_user.mention, wallet)

    if res:
        txt = f"""
        Заявка на вывод средств
        
        От:
        Имя - {m.from_user.first_name} 
        ID - {m.from_user.id}
        Кошелек - <code>{wallet}</code>
        Сумма - {amount}
        """
        await m.bot.send_message(
            5480642013, dedent(txt), reply_markup=admin_wd_kb(res))
        
        await asyncio.sleep(.2)
        ok_txt = """
        ✅ Ваша заявка отправлена администрации

        Вы находитесь в главном меню. Тут должно быть какое-то сообщение...
        """
        logging.info(
            f"Пользователь {m.from_user.id} подал заявку на вывод {amount}руб")

        img = types.InputFile("img/start.png")
        await m.answer_photo(img, dedent(ok_txt), reply_markup=investor_kb)

    else:
        await m.answer("⚠️ Возникла ошибка!")


@rate_limit(limit=1)
async def dividends_cmd(c: types.CallbackQuery):
    txt = "💬 Выберите кому хотите пополнить баланс"

    try:
        await c.message.edit_text(txt, reply_markup=div_kb)
    except Exception as error:
        logging.error(
            f"Ошибка редакитрования сообщения dividends_cmd\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def pay_to_one_cmd(c: types.CallbackQuery, state: FSMContext):
    txt = "💬 Введите ID инвестора\n\n/cancel - отмена"
    await c.message.answer(txt)
    await state.set_state("id_for_dividends")
    await c.answer()


@rate_limit(limit=1)
async def amount_to_one(m: types.Message, state: FSMContext):
    if not m.text.strip().isdigit():
        await m.answer("⚠️ ID необходимо ввести цифрами\n\n/cancel - отмена")
    else:
        await m.answer("💬 Введите сумму\n\n/cancel - отмена")
        await state.set_state("amount_for_one")
        await state.update_data(user_id=m.text.strip())


@rate_limit(limit=1)
async def text_to_one(m: types.Message, state: FSMContext):
    try:
        amount = float(m.text.strip().replace(",", "."))
    except Exception as error:
        logging.error(f"Ошибка! {m.text} не может быть FLOAT\n{error}")
        await m.answer("⚠️ Ошибка! Введите сумму цифрами\n\n/cancel - отмена")
        return

    await m.answer("💬 Введите текст для отправки\n\n/cancel - отмена")
    await state.set_state("text_for_one")
    await state.update_data(amount=amount)


@rate_limit(limit=1)
async def send_dividends_to_one(m: types.Message, state: FSMContext):
    data = await state.get_data()
    user_id = int(data.get("user_id"))
    amount = float(data.get("amount"))
    await state.finish()

    db = m.bot.get("db")
    res = await dividends_to_one(db, user_id, amount, "add")

    if res:
        await m.answer(f"✅ Инвестору {user_id} начислено {amount}руб на баланс")
        logging.info(f"Пользователю {user_id} начислено {amount}руб")

        if m.photo:
            text = m.caption or "Без текста"
            img = "С изображенем"
        else:
            text = m.text
            img = "Текст"

        msg_to = str(user_id)

        await add_new_msgs(db, text, msg_to, img)

    else:
        await m.answer("⚠️ Возникла ошибка")

    await asyncio.sleep(.1)

    txt = "💬 Выберите кому хотите пополнить баланс"
    await m.answer(txt, reply_markup=div_kb)


@rate_limit(limit=1)
async def pay_to_many_cmd(c: types.CallbackQuery, state: FSMContext, callback_data: dict):
    count = int(callback_data.get("count"))
    await c.message.answer("💬 Введите сумму\n\n/cancel - отмена")
    await state.set_state("amount_to_many")
    await state.update_data(count=count)
    await c.answer()


@rate_limit(limit=1)
async def text_to_many(m: types.Message, state: FSMContext):
    try:
        amount = float(m.text.strip().replace(",", "."))
    except Exception as error:
        logging.error(f"Ошибка! {m.text} не может быть FLOAT\n{error}")
        await m.answer("⚠️ Ошибка! Введите сумму цифрами\n\n/cancel - отмена")
        return

    await m.answer("💬 Введите текст для отправки\n\n/cancel - отмена")
    await state.set_state("text_for_many")
    await state.update_data(amount=amount)


@rate_limit(limit=1)
async def send_dividends_to_many(m: types.Message, state: FSMContext):
    data = await state.get_data()
    count = int(data.get("count"))
    amount = float(data.get("amount"))
    await state.finish()

    await m.answer("💬 Отправляю средства пользователям")
    await m.answer_chat_action("typing")

    db = m.bot.get("db")
    invs = await dividends_to_many(db, count, amount, "add")
    logging.info(f"Инвесторы получили по {amount}руб")

    if m.photo:
        text = m.caption or "Без текста"
        img = "С изображенем"
    else:
        text = m.text
        img = "Текст"

    if count == 50:
        msg_to = "Топ 50"
    elif count == 20:
        msg_to = "Топ 20"
    elif count == 10:
        msg_to = "Топ 10"
    else:
        msg_to = "Инвесторам"

    await add_new_msgs(db, text, msg_to, img)

    await asyncio.sleep(.1)

    await m.answer("✅ Начисление средств завершено")

    await asyncio.sleep(.1)

    txt = "💬 Выберите кому хотите пополнить баланс"
    await m.answer(txt, reply_markup=div_kb)


def balance_handlers(dp: Dispatcher):
    dp.register_callback_query_handler(
        withdraw_cmd, NotBanned(), text="withdraw")
    dp.register_callback_query_handler(
        withdraw_other_cmd, NotBanned(), text="withdraw_other")
    dp.register_callback_query_handler(
        withdraw_qiwi_cmd, NotBanned(), text="withdraw_qiwi")
    dp.register_message_handler(
        get_wallet, NotBanned(), state="withdraw_amount")
    dp.register_message_handler(
        new_withdraw, NotBanned(), state="wallet_for_withdraw")

    dp.register_callback_query_handler(
        dividends_cmd, IsAdmin(), text="dividends")
    dp.register_callback_query_handler(
        pay_to_one_cmd, IsAdmin(), text="id_pay_div")
    dp.register_message_handler(
        amount_to_one, IsAdmin(), state="id_for_dividends")
    dp.register_message_handler(text_to_one, IsAdmin(), state="amount_for_one")
    dp.register_message_handler(
        send_dividends_to_one, IsAdmin(), state="text_for_one")
    dp.register_callback_query_handler(
        pay_to_many_cmd, IsAdmin(), div_cb.filter())
    dp.register_message_handler(
        text_to_many, IsAdmin(), state="amount_to_many")
    dp.register_message_handler(
        send_dividends_to_many, IsAdmin(), state="text_for_many")
