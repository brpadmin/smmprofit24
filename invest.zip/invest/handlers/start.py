import logging
import random
from textwrap import dedent

from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from db.models import Invester
from db.queries import check_or_add_user, get_messages, get_profile, get_stats
from filters.filters import IsAdmin, NotBanned
from keyboards.admin_keyboard import admin_kb
from keyboards.keyboars import back_btn, investor_kb, start_kb
from middlewares.throttling import rate_limit
from utils.others import stats_text


@rate_limit(limit=1)
async def start_cmd(m: types.Message):
    args = m.get_args()
    referrer_id = int(args) if args else 0

    db = m.bot.get("db")
    res = await check_or_add_user(db, m.from_user.id, referrer_id, m.from_user.mention.lower())

    img = types.InputFile("img/start.png")

    if res == "user":
        txt_q = await get_messages(db)
        hello_txt = txt_q[0]
        await m.answer_photo(img, dedent(hello_txt).format(name=m.from_user.first_name), reply_markup=start_kb)
    else:
        txt = "Вы находитесь в главном меню. Выберите интересующую вас информацию"
        await m.answer_photo(img, txt, reply_markup=investor_kb)


@rate_limit(limit=1)
async def back_to_menu(c: types.CallbackQuery):
    db = c.bot.get("db")
    user: Invester = await get_profile(db, c.from_user.id)

    img = types.InputFile("img/start.png")
    if user.status == "user":
        txt_q = await get_messages(db)
        hello_txt = txt_q[0]

        media = types.InputMedia(
            caption=dedent(hello_txt).format(name=c.from_user.first_name), media=img)
        try:
            await c.message.edit_media(media, reply_markup=start_kb)
        except Exception as error:
            logging.error(f"Ошибка редакитрования медиа back_to_menu\n{error}")
    else:
        txt = "Вы находитесь в главном меню. Выберите интересующую вас информацию"
        media = types.InputMedia(caption=txt, media=img)
        try:
            await c.message.edit_media(media, reply_markup=investor_kb)
        except Exception as error:
            logging.error(f"Ошибка редакитрования медиа back_to_menu\n{error}")


@rate_limit(limit=1)
async def profile_info(c: types.CallbackQuery):
    db = c.bot.get("db")
    user: Invester = await get_profile(db, c.from_user.id)

    if user.status == "user":
        txt = f"""
        <b>Имя</b> - {c.from_user.mention}
        <b>ID</b> - {c.from_user.id}
        <b>Статус</b> - <b>Visitor🪪</b>

        <b>Количество приглашенных вами участников:</b>
        <b>Visitor🪪</b> - (недоступно🚫)
        <b>Premium🎫</b> - (недоступно🚫)

        <b>Общая прибыль:</b> (недоступно🚫)
        <b>Текущий баланс:</b> (недоступно🚫)

        <b>Реферальная ссылка:</b> (недоступно🚫)

        <i>📌P.S.Для получения доступа ко всем функциям профиля, вы должны быть <b>Premium🎫</b> участником проекта!</i>
        """
        img = types.InputFile("img/user_profile.png")
        media = types.InputMedia(caption=dedent(txt), media=img)
        try:
            await c.message.edit_media(media, reply_markup=start_kb)
        except Exception as error:
            logging.error(f"Ошибка редакитрования медиа profile_info\n{error}")
    else:
        txt = f"""
        <b>Имя</b> - {c.from_user.mention}
        <b>ID</b> - {c.from_user.id}
        <b>Статус</b> - <b>Premium🎫</b>

        <b>Количество приглашенных:</b>
        <b>Visitor🪪</b> - {user.ref_count}
        <b>Premium🎫</b> - {user.active_refs}

        <b>Общая прибыль:</b> {user.total_ref_cash}руб
        <b>Текущий баланс:</b> {user.balance}руб

        <b>Реферальная ссылка:</b>
        <em>(Нажмите на неё, чтобы скопировать)</em>\n\n
        <code>{user.ref_link}</code>
        \n
        <i>📌P.S. Читайте мануалы, по привлечению рефералов!</i>
        """
        img = types.InputFile("img/invest_profile.png")
        media = types.InputMedia(caption=dedent(txt), media=img)
        try:
            await c.message.edit_media(media, reply_markup=investor_kb)
        except Exception as error:
            logging.error(f"Ошибка редакитрования медиа profile_info\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def cancel_cmd(m: types.Message, state: FSMContext):
    await state.finish()
    await m.reply("✅ Действие отменено")

    db = m.bot.get("db")
    user: Invester = await get_profile(db, m.from_user.id)

    img = types.InputFile("img/start.png")
    if user.status == "user":
        txt_q = await get_messages(db)
        hello_txt = txt_q[0]
        await m.answer_photo(img, dedent(hello_txt).format(name=m.from_user.first_name), reply_markup=start_kb)
    else:
        txt = "Вы находитесь в главном меню. Выберите интересующую вас информацию"
        await m.answer_photo(img, txt, reply_markup=investor_kb)


@rate_limit(limit=1)
async def cancel_admin_cmd(m: types.Message, state: FSMContext):
    await state.finish()
    await m.reply("✅ Действие отменено")

    db = m.bot.get("db")
    res = await get_stats(db)
    txt = await stats_text(res)

    await m.answer(dedent(txt), reply_markup=admin_kb)


@rate_limit(limit=1)
async def support_cmd(c: types.CallbackQuery):
    txt = """
    <b>Вопрос 1</b> ❓
    - Здесь должен быть какой-то ответ на первый вопрос

    <b>Вопрос 2</b> ❓
    - Здесь должен быть какой-то ответ на второй вопрос

    <b>Вопрос 3</b> ❓
    - Здесь должен быть какой-то ответ на третий вопрос


    Если у Вас остались еще какие-то вопросы пишите сюда @moderator_resolved
    """
    img = types.InputFile("img/faq.png")
    media = types.InputMedia(caption=dedent(txt), media=img)
    try:
        await c.message.edit_media(media, reply_markup=back_btn)
    except Exception as error:
        logging.error(f"Ошибка редакитрования медиа support_cmd\n{error}")


@rate_limit(limit=1)
async def close_cmd(c: types.CallbackQuery):
    await c.message.delete()
    await c.answer()


@rate_limit(limit=1)
async def project_info(c: types.CallbackQuery):
    db = c.bot.get("db")
    user: Invester = await get_profile(db, c.from_user.id)
    info_txt = await get_messages(db)

    if user.status == "user":
        txt = info_txt[1]
        img = types.InputFile("img/user_info.png")
        media = types.InputMedia(caption=dedent(txt), media=img)
        try:
            await c.message.edit_media(media, reply_markup=start_kb)
        except Exception as error:
            logging.error(f"Ошибка редакитрования медиа project_info\n{error}")

    else:
        txt = info_txt[2]
        img = types.InputFile("img/invest_info.png")
        media = types.InputMedia(caption=dedent(txt), media=img)
        try:
            await c.message.edit_media(media, reply_markup=investor_kb)
        except Exception as error:
            logging.error(f"Ошибка редакитрования медиа project_info\n{error}")

    await c.answer()


@rate_limit(limit=1)
async def admin_cmd(m: types.Message):
    db = m.bot.get("db")
    res = await get_stats(db)
    txt = await stats_text(res)

    await m.answer(dedent(txt), reply_markup=admin_kb)


def start_handlers(dp: Dispatcher):
    dp.register_message_handler(start_cmd, NotBanned(), commands="start")
    dp.register_message_handler(
        cancel_cmd, NotBanned(), commands="cancel", state=["withdraw_amount", "wallet_for_withdraw"])
    dp.register_message_handler(
        cancel_admin_cmd, IsAdmin(), commands="cancel", state="*")
    dp.register_callback_query_handler(
        back_to_menu, NotBanned(), text="to_menu")
    dp.register_callback_query_handler(
        profile_info, NotBanned(), text="profile")

    dp.register_callback_query_handler(
        support_cmd, NotBanned(), text="support")
    dp.register_callback_query_handler(
        project_info, NotBanned(), text="project_info")
    dp.register_message_handler(admin_cmd, IsAdmin(), commands="admin")
    dp.register_callback_query_handler(close_cmd, text="close")
