import logging

import openpyxl
from db.models import BalanceChange, Invester, InvestSettings, MessageHistory

from utils.chek_pay import get_qiwi_balance


async def stats_text(data: dict):
    setts: InvestSettings = data.get("setts")
    try:
        balance = await get_qiwi_balance(setts.qiwi_api, setts.qiwi_wallet)
    except Exception as error:
        logging.error(f"Ошибка получения баланса кошелька\n{error}")
        balance = "???"

    new_users = data.get("new_users")
    new_investors = data.get("new_investors")

    txt = f"""
    Всего уникальных пользователей - {setts.total_users}
    Всего инвесторов - {setts.total_investers}
    Новых пользователей за 24 часа - {new_users}
    Новых инвесторов за 24 часа - {new_investors}
    Общая сумма инвестиций - {setts.total_invests}руб
    Общая прибыль - {setts.profit}руб
    Текущий баланс кошелька - {balance}руб
    """

    return txt


async def get_users_file(data, action):
    wb = openpyxl.Workbook()
    ws = wb.active

    ws['A1'] = 'id'
    ws['B1'] = 'username'
    ws['C1'] = 'ref_count'
    ws['D1'] = 'total_profit'
    ws['E1'] = 'balance'
    ws['F1'] = 'withdraw'

    index = 2
    user: Invester
    for user in data:
        ws[f'A{index}'] = user.id
        ws[f'B{index}'] = user.username
        ws[f'C{index}'] = user.ref_count
        ws[f'D{index}'] = user.total_ref_cash
        ws[f'E{index}'] = user.balance
        ws[f'F{index}'] = user.total_ref_cash - user.balance

        index += 1

    wb.save(f"files/{action}.xlsx")

    return True


async def get_user_history(data):
    wb = openpyxl.Workbook()
    ws = wb.active

    ws['A1'] = 'id'
    ws['B1'] = 'date'
    ws['C1'] = 'from'
    ws['D1'] = 'type'
    ws['E1'] = 'amount'
    ws['F1'] = 'ref_lvl'
    ws['G1'] = 'ref_name'

    index = 2
    his: BalanceChange
    for his in data:
        ws[f'A{index}'] = his.user_id
        ws[f'B{index}'] = his.date_str
        if his.change_from == "ref":
            ws[f'C{index}'] = "referral"
            ws[f'D{index}'] = his.change_type
            ws[f'E{index}'] = his.amount
            ws[f'F{index}'] = his.ref_lvl
            ws[f'G{index}'] = his.ref_name

        elif his.change_from == "admin":
            ws[f'C{index}'] = "admin"
            ws[f'D{index}'] = his.change_type
            ws[f'E{index}'] = his.amount
            ws[f'F{index}'] = "-"
            ws[f'G{index}'] = "-"

        else:
            ws[f'C{index}'] = "user"
            ws[f'D{index}'] = his.change_type
            ws[f'E{index}'] = his.amount
            ws[f'F{index}'] = "-"
            ws[f'G{index}'] = "-"

        index += 1

    wb.save(f"files/user_history.xlsx")

    return True


async def get_msg_history(data):
    wb = openpyxl.Workbook()
    ws = wb.active

    ws['A1'] = 'Дата'
    ws['B1'] = 'Кому'
    ws['C1'] = 'Текст сообщения'
    ws['D1'] = 'Содержимое'

    index = 2
    item: MessageHistory
    for item in data:
        ws[f'A{index}'] = item.date
        ws[f'B{index}'] = item.msg_to
        ws[f'C{index}'] = item.text
        ws[f'D{index}'] = item.image

        index += 1

    wb.save(f"files/messages_history.xlsx")

    return True
