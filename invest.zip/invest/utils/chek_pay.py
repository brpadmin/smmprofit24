from glQiwiApi import QiwiP2PClient, QiwiWallet


async def check_wallet_pay(amount, code, qiwi_token, qiwi_phone):
    async with QiwiWallet(qiwi_token, qiwi_phone) as wallet:
        history = await wallet.history()
        for pay in history:
            if str(pay.comment) == str(code):
                if float(amount) <= float(pay.sum.amount):
                    return True

    return False


async def create_new_bill(amount, code, qiwi_ptp):
    async with QiwiP2PClient(secret_p2p=qiwi_ptp) as p2p:
        bill = await p2p.create_p2p_bill(amount=amount, comment=code, pay_source_filter=["qw", "card", "mobile"])
        return [bill.id, bill.pay_url]


async def check_bill_for_pay(bill_id, qiwi_ptp):
    async with QiwiP2PClient(secret_p2p=qiwi_ptp) as p2p:
        bill_status = await p2p.get_bill_status(bill_id)

    return bill_status == "PAID"


async def get_qiwi_balance(qiwi_token, qiwi_phone):
    async with QiwiWallet(qiwi_token, qiwi_phone) as wallet:
        balance = await wallet.get_balance()
        amount = balance.amount

    return amount


async def send_money(wallet, amount, qiwi_token, qiwi_phone):
    wal = wallet
    am = amount
    async with QiwiWallet(qiwi_token, qiwi_phone) as wallet:
        await wallet.transfer_money(to_phone_number=wal, amount=am)

    return True
