from aiogram import types
from aiogram.utils.callback_data import CallbackData

admin_wd_cb = CallbackData("wd", "wid", "act")


def admin_wd_kb(w_id):
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [
                types.InlineKeyboardButton("✅ Отправлено", callback_data=admin_wd_cb.new(
                    wid=w_id, act="accept")),
                types.InlineKeyboardButton("❌ Отклонить", callback_data=admin_wd_cb.new(
                    wid=w_id, act="decline"))
            ],
            [
                types.InlineKeyboardButton("Отправить автоматически", callback_data=admin_wd_cb.new(
                    wid=w_id, act="auto"))
            ],
            [
                types.InlineKeyboardButton(
                    "id info", callback_data=admin_wd_cb.new(wid=w_id, act="info")),
                types.InlineKeyboardButton(
                    "id history $", callback_data=admin_wd_cb.new(wid=w_id, act="hist"))
            ]
        ]
    )
    return keyboard


admin_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Список юзеров", callback_data="user_list"),
            types.InlineKeyboardButton(
                "Изменить %", callback_data="change_percents"),
            types.InlineKeyboardButton(
                "Изменить Qiwi", callback_data="change_qiwi")
        ],
        [
            types.InlineKeyboardButton(
                "Список инвесторов", callback_data="invest_list"),
            types.InlineKeyboardButton(
                "Изменить $", callback_data="change_amount"),
            types.InlineKeyboardButton(
                "Рассылка", callback_data="create_msgs")
        ],
        [
            types.InlineKeyboardButton(
                "ID CONTROL", callback_data="block_list"),
            types.InlineKeyboardButton(
                "Запросы на вывод", callback_data="wd_orders"),
            types.InlineKeyboardButton(
                "Приветствие/инфо", callback_data="change_msgs")
        ],
        [
            types.InlineKeyboardButton(
                "Пополнить баланс пользователям", callback_data="dividends"),
            types.InlineKeyboardButton(
                "Списать баланс", callback_data="minus_balance")
        ],
        [
            types.InlineKeyboardButton(
                "Тех. работы", callback_data="maintentance")
        ]
    ]
)


change_messages_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Изменить приветствие", callback_data="change_hello"),
            types.InlineKeyboardButton(
                "Изменить о проекте", callback_data="change_proj"),
            types.InlineKeyboardButton(
                "Изменить инфо", callback_data="change_info"),
        ],
        [
            types.InlineKeyboardButton(
                "↩️ Назад", callback_data="to_admin"),
        ]
    ]
)


user_list_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Получить в сообщении", callback_data="users_in_msg"),
            types.InlineKeyboardButton(
                "Получить в файле", callback_data="users_in_xlsx"),
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_admin")
        ]
    ]
)


inv_list_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Топ 50", callback_data="inv_50_msg"),
            types.InlineKeyboardButton(
                "Топ 20", callback_data="inv_20_msg"),
            types.InlineKeyboardButton(
                "Топ 10", callback_data="inv_10_msg"),
        ],
        [
            types.InlineKeyboardButton(
                "Топ 50 файл", callback_data="inv_50_file"),
            types.InlineKeyboardButton(
                "Топ 20 файл", callback_data="inv_20_file"),
            types.InlineKeyboardButton(
                "Топ 10 файл", callback_data="inv_10_file"),
        ],
        [
            types.InlineKeyboardButton(
                "Все инвесторы", callback_data="inv_in_msg"),
            types.InlineKeyboardButton(
                "Все инвесторы файлом", callback_data="inv_in_xlsx"),
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_admin")
        ]
    ]
)


bl_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Добавить в ЧС", callback_data="add_to_bl"),
            types.InlineKeyboardButton(
                "Убрать из ЧС", callback_data="del_from_bl"),
        ],
        [
            types.InlineKeyboardButton(
                "Выдать доступ", callback_data="give_access"),
            types.InlineKeyboardButton(
                "id info", callback_data="id_info"),
        ],
        [
            types.InlineKeyboardButton(
                "id history $", callback_data="admin_bal_history_m"),
            types.InlineKeyboardButton(
                "id history $ file", callback_data="admin_bal_history_f"),
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_admin")
        ]
    ]
)


msgs_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Для всех", callback_data="msgs_to_all_users"),
            types.InlineKeyboardButton(
                "Для новичков", callback_data="msgs_to_novice"),
            types.InlineKeyboardButton(
                "Для инвесторов", callback_data="msgs_to_invs"),
        ],
        [
            types.InlineKeyboardButton(
                "Скачать историю рассылок", callback_data="msg_history_file")
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_admin")
        ]
    ]
)


amount_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Сумма взноса", callback_data="invest_amount"),
            types.InlineKeyboardButton(
                "Сумма вывода", callback_data="withdraw_amount"),
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_admin")
        ]
    ]
)


change_qiwi_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Qiwi API", callback_data="qiwi_api"),
            types.InlineKeyboardButton(
                "Qiwi P2P", callback_data="qiwi_ptp"),
            types.InlineKeyboardButton(
                "Qiwi номер", callback_data="qiwi_wlt"),
        ],
        [
            types.InlineKeyboardButton(
                "Оплата по номеру", callback_data="on_off_wallet_pay")
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_admin")
        ]
    ]
)


mntc_on = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Включить тех.работы", callback_data="mtns_on")
        ],
        [
            types.InlineKeyboardButton(
                "❌ Закрыть окно", callback_data="close")
        ],
    ]
)


mntc_off = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Выключить тех.работы", callback_data="mtns_off")
        ],
        [
            types.InlineKeyboardButton(
                "❌ Закрыть окно", callback_data="close")
        ],
    ]
)


div_cb = CallbackData("div", "count")


div_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Топ 10", callback_data=div_cb.new(count=10)),
            types.InlineKeyboardButton(
                "Топ 20", callback_data=div_cb.new(count=20)),
            types.InlineKeyboardButton(
                "Топ 50", callback_data=div_cb.new(count=50)),
        ],
        [
            types.InlineKeyboardButton(
                "Всем инвесторам", callback_data=div_cb.new(count=0)),
        ],
        [
            types.InlineKeyboardButton("По ID", callback_data="id_pay_div"),
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_admin"),
        ]
    ]
)


close_btn = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "❌ Закрыть", callback_data="close")
        ],
    ]
)

qiwi_on = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Включить оплату по номеру", callback_data="qiwi_on")
        ],
        [
            types.InlineKeyboardButton(
                "❌ Закрыть окно", callback_data="close")
        ],
    ]
)


qiwi_off = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Выключить оплату по номеру", callback_data="qiwi_off")
        ],
        [
            types.InlineKeyboardButton(
                "❌ Закрыть окно", callback_data="close")
        ],
    ]
)


minus_cb = CallbackData("minus", "count")


minus_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Списать Топ 10", callback_data=minus_cb.new(count=10)),
            types.InlineKeyboardButton(
                "Списать Топ 20", callback_data=minus_cb.new(count=20)),
            types.InlineKeyboardButton(
                "Списать Топ 50", callback_data=minus_cb.new(count=50)),
        ],
        [
            types.InlineKeyboardButton(
                "Списать всем инвесторам", callback_data=minus_cb.new(count=0)),
        ],
        [
            types.InlineKeyboardButton(
                "Списать по ID", callback_data="minus_bal_id"),
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_admin"),
        ]
    ]
)
