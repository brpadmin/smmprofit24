from aiogram import types
from aiogram.utils.callback_data import CallbackData

start_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Premium🎫", callback_data="invest"),
            types.InlineKeyboardButton("Профиль👤", callback_data="profile"),
            types.InlineKeyboardButton(
                "О проекте📃", callback_data="project_info")
        ],
        [
            types.InlineKeyboardButton(
                "Тех. поддержка🛠", url='https://t.me/smmprofit_support'),
        ]
    ]
)


investor_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Вывод💸", callback_data="withdraw"),
            types.InlineKeyboardButton("Профиль👤", callback_data="profile"),
            types.InlineKeyboardButton(
                "Мануалы📁", callback_data="project_info")
        ],
        [
            types.InlineKeyboardButton(
                "История🧾", callback_data="user_bal_history"),
            types.InlineKeyboardButton(
                "Тех. поддержка🛠", url='https://t.me/smmprofit_support'),
        ]
    ]
)


back_btn = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "↩️ Назад", callback_data="to_menu"),
        ]
    ]
)

invest_ptp_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Выставить счет", callback_data="pay_wallet"),
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_menu")
        ]
    ]
)

invest_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Выставить счет", callback_data="pay_wallet"),
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_menu")
        ]
    ]
)


paid_cb = CallbackData("paid", "ord_id", "method")


def paid_btn(order_id, method):
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [
                types.InlineKeyboardButton(
                    "Я оплатил(а)", callback_data=paid_cb.new(ord_id=order_id, method=method)),
            ],
            [
                types.InlineKeyboardButton("↩️ Назад", callback_data="to_menu")
            ]
        ]
    )
    return keyboard


bill_cb = CallbackData("bill", "i_id", "b_id")


def bill_kb(i_id, b_id, url):
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [
                types.InlineKeyboardButton(
                    "Перейти к оплате", url=url),
                types.InlineKeyboardButton(
                    "Я оплатил(а)", callback_data=bill_cb.new(i_id=i_id, b_id=b_id)),
            ],
            [
                types.InlineKeyboardButton("↩️ Назад", callback_data="to_menu")
            ]
        ]
    )
    return keyboard


wd_type_kb = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Вывести на QIWI🥝", callback_data="withdraw_qiwi"),
            types.InlineKeyboardButton(
                "Другой способ🤔", callback_data="withdraw_other")
        ],
        [
            types.InlineKeyboardButton("↩️ Назад", callback_data="to_menu")
        ]
    ]
)
